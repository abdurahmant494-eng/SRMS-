<?php
$host = '127.0.0.1';
$port = 8000;
$email = 'examofficer.http.verify@local.invalid';
$password = 'TempPass123!';
$term = 1;

$pdo = new PDO('mysql:host=localhost;dbname=srms_makumbusho;charset=utf8mb4', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$hash = password_hash($password, PASSWORD_DEFAULT);
$pdo->prepare('INSERT INTO tbl_staff (email, password, level, status) VALUES (?, ?, 4, 1)')->execute([$email, $hash]);
$staffId = (int)$pdo->lastInsertId();

function sendRequest($method, $path, $headers = [], $body = '')
{
    global $host, $port;
    $socket = stream_socket_client("tcp://{$host}:{$port}", $errno, $errstr, 10);
    if (!$socket) {
        throw new RuntimeException("Socket error: {$errstr} ({$errno})");
    }

    $headerBlock = strtoupper($method) . " {$path} HTTP/1.1\r\n";
    $headerBlock .= "Host: {$host}:{$port}\r\n";
    foreach ($headers as $name => $value) {
        $headerBlock .= $name . ': ' . $value . "\r\n";
    }
    if ($body !== '') {
        $headerBlock .= "Content-Length: " . strlen($body) . "\r\n";
    }
    $headerBlock .= "Connection: close\r\n\r\n";
    if ($body !== '') {
        $headerBlock .= $body;
    }

    fwrite($socket, $headerBlock);

    $response = '';
    while (!feof($socket)) {
        $response .= fread($socket, 8192);
    }
    fclose($socket);

    $parts = explode("\r\n\r\n", $response, 2);
    $headersPart = $parts[0];
    $bodyPart = $parts[1] ?? '';
    $lines = explode("\r\n", $headersPart);
    $status = $lines[0];
    $parsedHeaders = [];
    foreach (array_slice($lines, 1) as $line) {
        if (strpos($line, ':') !== false) {
            [$name, $value] = explode(':', $line, 2);
            $parsedHeaders[trim($name)] = trim($value);
        }
    }

    return ['status' => $status, 'headers' => $parsedHeaders, 'body' => $bodyPart];
}

$login = sendRequest('POST', '/script/core/auth.php', [], http_build_query(['username' => $email, 'password' => $password]));
$setCookies = [];
if (isset($login['headers']['Set-Cookie'])) {
    $setCookies[] = $login['headers']['Set-Cookie'];
}
$cookieHeader = '';
foreach ($setCookies as $cookie) {
    if (preg_match('/(__SRMS__logged|__SRMS__key)=([^;]+)/', $cookie, $m)) {
        $cookieHeader .= $m[1] . '=' . $m[2] . '; ';
    }
}
$cookieHeader = rtrim($cookieHeader, '; ');

$examPage = sendRequest('GET', '/script/admin/exams.php', ['Cookie' => $cookieHeader]);
$save = sendRequest('POST', '/script/admin/core/save_exam_schedule.php', ['Cookie' => $cookieHeader, 'Content-Type' => 'application/json'], json_encode([
    'term' => $term,
    'slots' => [
        ['slot_key' => 'monday_0900', 'subject_id' => '1'],
        ['slot_key' => 'tuesday_0900', 'subject_id' => '2'],
    ],
]));
$get = sendRequest('GET', '/script/admin/core/get_exam_schedule.php?term=' . $term, ['Cookie' => $cookieHeader]);
$release = sendRequest('POST', '/script/admin/core/release_exam_results.php', ['Cookie' => $cookieHeader, 'Content-Type' => 'application/x-www-form-urlencoded'], http_build_query(['term' => $term]));

$scheduled = $pdo->prepare('SELECT slot_key, subject FROM tbl_exam_schedules WHERE term = ? ORDER BY slot_key ASC');
$scheduled->execute([$term]);
$scheduledRows = $scheduled->fetchAll(PDO::FETCH_ASSOC);

$releaseRow = $pdo->prepare('SELECT released, released_by FROM tbl_exam_releases WHERE term = ?');
$releaseRow->execute([$term]);
$releaseRows = $releaseRow->fetchAll(PDO::FETCH_ASSOC);

$pdo->prepare('DELETE FROM tbl_login_sessions WHERE staff = ?')->execute([$staffId]);
$pdo->prepare('DELETE FROM tbl_exam_schedules WHERE term = ?')->execute([$term]);
$pdo->prepare('DELETE FROM tbl_exam_releases WHERE term = ?')->execute([$term]);
$pdo->prepare('DELETE FROM tbl_staff WHERE id = ?')->execute([$staffId]);

$report = [
    'login' => [
        'status' => $login['status'],
        'cookieHeader' => $cookieHeader,
        'location' => $login['headers']['Location'] ?? null,
    ],
    'examPage' => [
        'status' => $examPage['status'],
        'containsExamManagement' => strpos($examPage['body'], 'Exam Management') !== false,
        'containsTitle' => strpos($examPage['body'], '<title>') !== false,
    ],
    'save' => [
        'status' => $save['status'],
        'body' => $save['body'],
    ],
    'get' => [
        'status' => $get['status'],
        'body' => $get['body'],
    ],
    'release' => [
        'status' => $release['status'],
        'body' => $release['body'],
    ],
    'db' => [
        'scheduledRows' => $scheduledRows,
        'releaseRows' => $releaseRows,
    ],
];

echo json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
?>