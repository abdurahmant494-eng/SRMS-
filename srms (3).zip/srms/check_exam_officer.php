<?php
require_once('script/db/config.php');

try {
    $conn = new PDO('mysql:host='.DBHost.';dbname='.DBName.';charset='.DBCharset.';collation='.DBCollation.';prefix='.DBPrefix.'', DBUser, DBPass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check all staff with level 4 (exam officer)
    $stmt = $conn->prepare("SELECT id, fname, lname, email, level, status, password FROM tbl_staff WHERE level = 4");
    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($results) > 0) {
        echo "Exam Officer(s) found:\n";
        foreach ($results as $row) {
            echo "ID: " . $row['id'] . "\n";
            echo "Name: " . $row['fname'] . " " . $row['lname'] . "\n";
            echo "Email: " . $row['email'] . "\n";
            echo "Level: " . $row['level'] . "\n";
            echo "Status: " . $row['status'] . "\n";
            echo "Password Hash: " . substr($row['password'], 0, 20) . "...\n";
            echo "---\n";
        }
    } else {
        echo "No exam officer account found. Let me create one.\n";
        
        // Create exam officer account
        $password = password_hash('12345678', PASSWORD_BCRYPT);
        $stmt = $conn->prepare("INSERT INTO tbl_staff (fname, lname, gender, email, password, level, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $result = $stmt->execute(['Exam', 'Officer', 'Male', 'exam.officer@srms.test', $password, 4, 1]);
        
        if ($result) {
            echo "Exam officer account created successfully!\n";
            echo "Email: exam.officer@srms.test\n";
            echo "Password: 12345678\n";
        } else {
            echo "Failed to create exam officer account\n";
        }
    }
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
}
?>
