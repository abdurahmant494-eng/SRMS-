<?php
chdir('../../');
session_start();
require_once('db/config.php');
require_once('const/check_session.php');

header('Content-Type: application/json');

if ($res != "1" || !in_array($level, array('0', '4'), true)) {
    http_response_code(403);
    echo json_encode(array('success' => false, 'message' => 'Unauthorized'));
    exit;
}

$term = isset($_GET['term']) ? (int)$_GET['term'] : 0;

try {
    $conn = new PDO('mysql:host='.DBHost.';dbname='.DBName.';charset='.DBCharset.';collation='.DBCollation.';prefix='.DBPrefix.'', DBUser, DBPass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $conn->exec("CREATE TABLE IF NOT EXISTS tbl_exam_schedules (
        id INT AUTO_INCREMENT PRIMARY KEY,
        term INT NOT NULL,
        slot_key VARCHAR(40) NOT NULL,
        subject INT NULL,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_term_slot (term, slot_key),
        KEY term_idx (term),
        KEY subject_idx (subject)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

    $conn->exec("CREATE TABLE IF NOT EXISTS tbl_exam_releases (
        id INT AUTO_INCREMENT PRIMARY KEY,
        term INT NOT NULL,
        released TINYINT NOT NULL DEFAULT 0,
        released_by INT NULL,
        released_at DATETIME NULL,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_term (term)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

    $schedule_stmt = $conn->prepare("SELECT s.slot_key, s.subject, subj.name AS subject_name
        FROM tbl_exam_schedules s
        LEFT JOIN tbl_subjects subj ON subj.id = s.subject
        WHERE s.term = ?
        ORDER BY s.slot_key ASC");
    $schedule_stmt->execute([$term]);
    $schedule_rows = $schedule_stmt->fetchAll(PDO::FETCH_ASSOC);

    $marks_stmt = $conn->prepare("SELECT COUNT(*) FROM tbl_exam_results WHERE term = ?");
    $marks_stmt->execute([$term]);
    $marks_count = (int)$marks_stmt->fetchColumn();

    $release_stmt = $conn->prepare("SELECT released FROM tbl_exam_releases WHERE term = ?");
    $release_stmt->execute([$term]);
    $release_row = $release_stmt->fetch(PDO::FETCH_ASSOC);
    $released = !empty($release_row) && (int)$release_row['released'] === 1;

    echo json_encode(array(
        'success' => true,
        'term' => $term,
        'released' => $released,
        'marks_count' => $marks_count,
        'slots' => $schedule_rows
    ));
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(array('success' => false, 'message' => 'Database error: ' . $e->getMessage()));
}