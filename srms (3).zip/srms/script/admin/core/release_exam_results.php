<?php
chdir('../../');
session_start();
require_once('db/config.php');
require_once('const/check_session.php');

header('Content-Type: application/json');

if ($res != "1" || !in_array($level, array('0', '4'), true)) {
    http_response_code(403);
    echo json_encode(array('success' => false, 'message' => 'Unauthorized'));
    exit;
}

$term = isset($_POST['term']) ? (int)$_POST['term'] : 0;

try {
    $conn = new PDO('mysql:host='.DBHost.';dbname='.DBName.';charset='.DBCharset.';collation='.DBCollation.';prefix='.DBPrefix.'', DBUser, DBPass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $conn->exec("CREATE TABLE IF NOT EXISTS tbl_exam_schedules (
        id INT AUTO_INCREMENT PRIMARY KEY,
        term INT NOT NULL,
        slot_key VARCHAR(40) NOT NULL,
        subject INT NULL,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_term_slot (term, slot_key),
        KEY term_idx (term),
        KEY subject_idx (subject)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

    $conn->exec("CREATE TABLE IF NOT EXISTS tbl_exam_releases (
        id INT AUTO_INCREMENT PRIMARY KEY,
        term INT NOT NULL,
        released TINYINT NOT NULL DEFAULT 0,
        released_by INT NULL,
        released_at DATETIME NULL,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_term (term)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

    $schedule_stmt = $conn->prepare("SELECT COUNT(*) FROM tbl_exam_schedules WHERE term = ?");
    $schedule_stmt->execute([$term]);
    $schedule_count = (int)$schedule_stmt->fetchColumn();

    $marks_stmt = $conn->prepare("SELECT COUNT(*) FROM tbl_exam_results WHERE term = ?");
    $marks_stmt->execute([$term]);
    $marks_count = (int)$marks_stmt->fetchColumn();

    if ($schedule_count < 1) {
        echo json_encode(array('success' => false, 'message' => 'Generate a timetable before releasing results.'));
        exit;
    }

    if ($marks_count < 1) {
        echo json_encode(array('success' => false, 'message' => 'No marks have been entered for this term yet.'));
        exit;
    }

    $release_stmt = $conn->prepare("INSERT INTO tbl_exam_releases (term, released, released_by, released_at) VALUES (?, 1, ?, NOW())
        ON DUPLICATE KEY UPDATE released = 1, released_by = VALUES(released_by), released_at = VALUES(released_at)");
    $release_stmt->execute([$term, $account_id]);

    echo json_encode(array('success' => true, 'message' => 'Results have been released for this term.'));
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(array('success' => false, 'message' => 'Database error: ' . $e->getMessage()));
}
