<?php
chdir('../../');
session_start();
require_once('db/config.php');
require_once('const/check_session.php');

header('Content-Type: application/json');

if ($res != "1" || !in_array($level, array('0', '4'), true)) {
    http_response_code(403);
    echo json_encode(array('success' => false, 'message' => 'Unauthorized'));
    exit;
}

$payload = file_get_contents('php://input');
$data = json_decode($payload, true);

if (!is_array($data)) {
    http_response_code(400);
    echo json_encode(array('success' => false, 'message' => 'Invalid request payload'));
    exit;
}

$term = isset($data['term']) ? (int)$data['term'] : 0;
$slots = isset($data['slots']) && is_array($data['slots']) ? $data['slots'] : array();

try {
    $conn = new PDO('mysql:host='.DBHost.';dbname='.DBName.';charset='.DBCharset.';collation='.DBCollation.';prefix='.DBPrefix.'', DBUser, DBPass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $conn->exec("CREATE TABLE IF NOT EXISTS tbl_exam_schedules (
        id INT AUTO_INCREMENT PRIMARY KEY,
        term INT NOT NULL,
        slot_key VARCHAR(40) NOT NULL,
        subject INT NULL,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_term_slot (term, slot_key),
        KEY term_idx (term),
        KEY subject_idx (subject)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

    $conn->exec("CREATE TABLE IF NOT EXISTS tbl_exam_releases (
        id INT AUTO_INCREMENT PRIMARY KEY,
        term INT NOT NULL,
        released TINYINT NOT NULL DEFAULT 0,
        released_by INT NULL,
        released_at DATETIME NULL,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_term (term)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

    $conn->beginTransaction();

    $delete_stmt = $conn->prepare("DELETE FROM tbl_exam_schedules WHERE term = ?");
    $delete_stmt->execute([$term]);

    $insert_stmt = $conn->prepare("INSERT INTO tbl_exam_schedules (term, slot_key, subject) VALUES (?, ?, ?)");
    foreach ($slots as $slot) {
        $slot_key = isset($slot['slot_key']) ? $slot['slot_key'] : '';
        $subject = isset($slot['subject_id']) && $slot['subject_id'] !== '' ? (int)$slot['subject_id'] : null;

        if ($term > 0 && $slot_key !== '' && $subject !== null) {
            $insert_stmt->execute([$term, $slot_key, $subject]);
        }
    }

    $release_stmt = $conn->prepare("INSERT INTO tbl_exam_releases (term, released, released_by, released_at) VALUES (?, 0, NULL, NULL)
        ON DUPLICATE KEY UPDATE released = 0, released_by = NULL, released_at = NULL");
    $release_stmt->execute([$term]);

    $conn->commit();

    echo json_encode(array('success' => true, 'message' => 'Timetable saved successfully.'));
} catch (PDOException $e) {
    if (isset($conn) && $conn->inTransaction()) {
        $conn->rollBack();
    }
    http_response_code(500);
    echo json_encode(array('success' => false, 'message' => 'Database error: ' . $e->getMessage()));
}
