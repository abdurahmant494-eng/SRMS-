<?php
chdir('../');
session_start();
require_once('db/config.php');
require_once('const/check_session.php');

if ($res != "1" || !in_array($level, array('0', '4'), true)) {
    header("location:../");
    exit;
}

$role_title = ($level == "4") ? 'Exam Officer' : 'Administrator';

try {
    $conn = new PDO('mysql:host='.DBHost.';dbname='.DBName.';charset='.DBCharset.';collation='.DBCollation.';prefix='.DBPrefix.'', DBUser, DBPass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $terms = array();
    $term_stmt = $conn->prepare("SELECT id, name FROM tbl_terms WHERE status = 1 ORDER BY name ASC");
    $term_stmt->execute();
    $terms = $term_stmt->fetchAll(PDO::FETCH_ASSOC);

    $subjects = array();
    $subject_stmt = $conn->prepare("SELECT id, name FROM tbl_subjects ORDER BY name ASC");
    $subject_stmt->execute();
    $subjects = $subject_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('Connection failed: ' . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Borana University - Exam Management</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<base href="../">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link rel="icon" href="images/icon.ico">
<link rel="stylesheet" type="text/css" href="cdn.jsdelivr.net/npm/bootstrap-icons%401.10.5/font/bootstrap-icons.css">
<link type="text/css" rel="stylesheet" href="loader/waitMe.css">
<style>
    .exam-shell { display: grid; grid-template-columns: 1.1fr 1.9fr; gap: 24px; align-items: start; }
    .exam-card { background: #fff; border-radius: 18px; padding: 22px; box-shadow: 0 8px 24px rgba(15, 23, 42, 0.08); }
    .exam-card h1, .exam-card h2, .exam-card h3 { color: #0f172a; }
    .exam-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 14px; margin-top: 16px; }
    .slot-card { min-height: 110px; border: 2px dashed #cbd5e1; border-radius: 16px; padding: 14px; background: #f8fafc; transition: border-color .2s ease, background-color .2s ease, transform .2s ease; }
    .slot-card.drag-over { border-color: #2563eb; background: #eff6ff; transform: translateY(-1px); }
    .slot-card.filled { border-style: solid; border-color: #34d399; background: #ecfdf5; }
    .slot-card .slot-label { font-size: 0.9rem; font-weight: 700; color: #334155; }
    .slot-card .slot-time { font-size: 0.82rem; color: #64748b; margin-top: 4px; }
    .slot-card .slot-subject { margin-top: 12px; font-weight: 700; color: #0f172a; }
    .slot-card .slot-empty { margin-top: 12px; color: #64748b; font-size: 0.92rem; }
    .subject-pool { display: grid; gap: 10px; margin-top: 12px; }
    .subject-item { border: 1px solid #dbeafe; border-radius: 14px; padding: 12px 14px; background: linear-gradient(180deg, #ffffff 0%, #f8fbff 100%); cursor: grab; font-weight: 600; color: #1e293b; }
    .subject-item:hover { border-color: #93c5fd; }
    .subject-item.dragging { opacity: 0.55; }
    .status-pill { display: inline-flex; align-items: center; border-radius: 999px; padding: 6px 12px; font-weight: 700; font-size: 0.9rem; }
    .status-ready { background: #ecfdf5; color: #065f46; }
    .status-pending { background: #fef3c7; color: #92400e; }
    .status-released { background: #dbeafe; color: #1d4ed8; }
    .helper-note { font-size: 0.92rem; color: #475569; margin-top: 8px; }
    .action-row { display: flex; gap: 12px; align-items: center; flex-wrap: wrap; margin-top: 16px; }
    .meta-row { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; margin-top: 14px; }
    .meta-box { background: #f8fafc; border-radius: 14px; padding: 12px; border: 1px solid #e2e8f0; }
    .meta-box strong { display: block; font-size: 1.1rem; color: #0f172a; }
    .meta-box span { color: #475569; font-size: 0.9rem; }
    @media (max-width: 991px) { .exam-shell { grid-template-columns: 1fr; } }
</style>
</head>
<body class="app sidebar-mini">
<header class="app-header"><a class="app-header__logo" href="javascript:void(0);">
<img src="images/logo/<?php echo WBLogo; ?>" alt="<?php echo WBName; ?> logo">
<span><?php echo WBName; ?></span>
</a>
<a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
<ul class="app-nav">
<li class="dropdown"><a class="app-nav__item" href="#" data-bs-toggle="dropdown" aria-label="Open Profile Menu"><i class="bi bi-person fs-4"></i></a>
<ul class="dropdown-menu settings-menu dropdown-menu-right">
<li><a class="dropdown-item" href="admin/profile"><i class="bi bi-person me-2 fs-5"></i> Profile</a></li>
<li><a class="dropdown-item" href="logout"><i class="bi bi-box-arrow-right me-2 fs-5"></i> Logout</a></li>
</ul></li>
</ul>
</header>

<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
<div class="app-sidebar__user">
<div>
<p class="app-sidebar__user-name"><?php echo $fname.' '.$lname; ?></p>
<p class="app-sidebar__user-designation"><?php echo $role_title; ?></p>
</div>
</div>
<ul class="app-menu">
<li><a class="app-menu__item" href="<?php echo ($level == '4') ? 'exam_officer' : 'admin'; ?>"><i class="app-menu__icon feather icon-monitor"></i><span class="app-menu__label">Dashboard</span></a></li>
<li><a class="app-menu__item active" href="admin/exams"><i class="app-menu__icon feather icon-file-text"></i><span class="app-menu__label">Exam Management</span></a></li>
</ul>
</aside>

<main class="app-content">
<div class="app-title">
<div>
<p class="dashboard-eyebrow">Borana University Exam Operations</p>
<h1>Exam Management</h1>
<p>Build the timetable for a selected term, save the draft, and release results once teachers have completed entry.</p>
</div>
</div>

<div class="exam-shell">
<div class="exam-card">
<h2>Select a term</h2>
<p class="helper-note">Choose a term and generate the timetable draft. Drag subjects into the slots below and save automatically.</p>
<div class="mb-3">
<label class="form-label">Term</label>
<select id="termSelect" class="form-control">
<?php foreach ($terms as $term): ?>
<option value="<?php echo (int)$term['id']; ?>"><?php echo htmlspecialchars($term['name']); ?></option>
<?php endforeach; ?>
</select>
</div>
<div class="action-row">
<button id="generateBtn" type="button" class="btn btn-primary">Generate Timetable</button>
<button id="releaseBtn" type="button" class="btn btn-success">Release Results</button>
</div>
<div class="meta-row">
<div class="meta-box">
<strong id="marksCount">0</strong>
<span>Marks entered</span>
</div>
<div class="meta-box">
<strong id="slotCount">0</strong>
<span>Assigned slots</span>
</div>
</div>
<div class="mt-3">
<span id="releaseBadge" class="status-pill status-pending">Pending Release</span>
</div>
<p id="saveStatus" class="helper-note"></p>

<h3 class="mt-4">Subject Pool</h3>
<p class="helper-note">Drag any subject into a time slot.</p>
<div id="subjectPool" class="subject-pool"></div>
</div>

<div class="exam-card">
<h2>Exam Timetable</h2>
<p class="helper-note">The timetable is saved automatically after each drop. Use the selected term to load or refresh the draft.</p>
<div id="slotGrid" class="exam-grid"></div>
</div>
</div>
</main>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>
<script src="loader/waitMe.js"></script>
<script src="js/forms.js"></script>
<script src="js/sweetalert2@11.js"></script>
<script>
const subjects = <?php echo json_encode($subjects, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
const slotConfig = [
    { key: 'monday_0900', label: 'Monday', time: '09:00 AM' },
    { key: 'monday_1100', label: 'Monday', time: '11:00 AM' },
    { key: 'tuesday_0900', label: 'Tuesday', time: '09:00 AM' },
    { key: 'tuesday_1100', label: 'Tuesday', time: '11:00 AM' },
    { key: 'wednesday_0900', label: 'Wednesday', time: '09:00 AM' },
    { key: 'wednesday_1100', label: 'Wednesday', time: '11:00 AM' },
    { key: 'thursday_0900', label: 'Thursday', time: '09:00 AM' },
    { key: 'thursday_1100', label: 'Thursday', time: '11:00 AM' },
    { key: 'friday_0900', label: 'Friday', time: '09:00 AM' },
    { key: 'friday_1100', label: 'Friday', time: '11:00 AM' }
];

let currentTerm = $('#termSelect').val();
let scheduleState = slotConfig.map(slot => ({ ...slot, subject_id: null, subject_name: '' }));
let releaseStatus = false;
let marksCount = 0;
let scheduleLoaded = false;

function getSubjectName(subjectId) {
    const match = subjects.find(item => String(item.id) === String(subjectId));
    return match ? match.name : '';
}

function renderSubjectPool() {
    const pool = $('#subjectPool');
    pool.empty();
    subjects.forEach(subject => {
        const card = $('<div>', {
            class: 'subject-item',
            text: subject.name,
            draggable: true,
            'data-subject-id': subject.id,
            'data-subject-name': subject.name
        });
        card.on('dragstart', function (event) {
            $(this).addClass('dragging');
            event.originalEvent.dataTransfer.setData('text/plain', JSON.stringify({ subject_id: subject.id, subject_name: subject.name }));
        });
        card.on('dragend', function () {
            $(this).removeClass('dragging');
        });
        pool.append(card);
    });
}

function renderSlots() {
    const grid = $('#slotGrid');
    grid.empty();
    scheduleState.forEach((slot) => {
        const filled = slot.subject_id !== null;
        const slotEl = $('<div>', { class: 'slot-card' + (filled ? ' filled' : ''), 'data-slot-key': slot.key });
        const label = $('<div>', { class: 'slot-label', text: slot.label });
        const time = $('<div>', { class: 'slot-time', text: slot.time });
        const content = filled
            ? $('<div>', { class: 'slot-subject', text: slot.subject_name })
            : $('<div>', { class: 'slot-empty', text: 'Drag a subject here' });

        slotEl.append(label, time, content);
        slotEl.on('dragover', function (event) {
            event.preventDefault();
            $(this).addClass('drag-over');
        });
        slotEl.on('dragleave', function () {
            $(this).removeClass('drag-over');
        });
        slotEl.on('drop', function (event) {
            event.preventDefault();
            $(this).removeClass('drag-over');
            const payload = JSON.parse(event.originalEvent.dataTransfer.getData('text/plain'));
            const targetKey = $(this).data('slot-key');
            const slotFound = scheduleState.find(item => item.key === targetKey);
            if (slotFound) {
                slotFound.subject_id = payload.subject_id;
                slotFound.subject_name = payload.subject_name;
                renderSlots();
                saveSchedule();
            }
        });
        grid.append(slotEl);
    });
    updateCounts();
}

function updateCounts() {
    const filledCount = scheduleState.filter(item => item.subject_id !== null).length;
    $('#slotCount').text(filledCount);
    $('#releaseBadge').removeClass('status-ready status-pending status-released');
    if (releaseStatus) {
        $('#releaseBadge').addClass('status-released').text('Results Released');
    } else if (filledCount > 0 && marksCount > 0) {
        $('#releaseBadge').addClass('status-ready').text('Ready to Release');
    } else {
        $('#releaseBadge').addClass('status-pending').text('Pending Release');
    }
    $('#releaseBtn').prop('disabled', !(filledCount > 0 && marksCount > 0 && !releaseStatus));
}

function setSaveStatus(message, type) {
    $('#saveStatus').text(message);
    $('#saveStatus').css('color', type === 'success' ? '#047857' : '#b45309');
}

function resetSchedule() {
    scheduleState = slotConfig.map(slot => ({ ...slot, subject_id: null, subject_name: '' }));
    renderSlots();
}

function saveSchedule() {
    if (!currentTerm) {
        return;
    }

    const payload = {
        term: currentTerm,
        slots: scheduleState
            .filter(slot => slot.subject_id !== null)
            .map(slot => ({ slot_key: slot.key, subject_id: String(slot.subject_id) }))
    };

    $.ajax({
        url: 'admin/core/save_exam_schedule.php',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(payload)
    }).done(function (response) {
        scheduleLoaded = true;
        setSaveStatus('Timetable saved successfully.', 'success');
        loadReleaseState();
    }).fail(function () {
        setSaveStatus('Unable to save timetable right now.', 'error');
    });
}

function loadReleaseState() {
    $.getJSON('admin/core/get_exam_schedule.php', { term: currentTerm }, function (response) {
        if (!response.success) {
            return;
        }
        releaseStatus = !!response.released;
        marksCount = Number(response.marks_count || 0);
        $('#marksCount').text(marksCount);
        updateCounts();
    });
}

function loadSchedule() {
    if (!currentTerm) {
        resetSchedule();
        return;
    }

    setSaveStatus('Loading timetable...', 'success');
    $.getJSON('admin/core/get_exam_schedule.php', { term: currentTerm }, function (response) {
        if (!response.success) {
            setSaveStatus('No timetable has been generated yet.', 'success');
            resetSchedule();
            return;
        }

        scheduleState = slotConfig.map(slot => ({ ...slot, subject_id: null, subject_name: '' }));
        (response.slots || []).forEach(slot => {
            const target = scheduleState.find(item => item.key === slot.slot_key);
            if (target) {
                target.subject_id = slot.subject_id;
                target.subject_name = slot.subject_name;
            }
        });
        releaseStatus = !!response.released;
        marksCount = Number(response.marks_count || 0);
        $('#marksCount').text(marksCount);
        renderSlots();
        scheduleLoaded = true;
        setSaveStatus('Timetable loaded for the selected term.', 'success');
        updateCounts();
    }).fail(function () {
        resetSchedule();
        setSaveStatus('Unable to load timetable details right now.', 'error');
    });
}

$('#generateBtn').on('click', function () {
    currentTerm = $('#termSelect').val();
    loadSchedule();
});

$('#termSelect').on('change', function () {
    currentTerm = $(this).val();
    loadSchedule();
});

$('#releaseBtn').on('click', function () {
    if (!currentTerm) {
        Swal.fire('Select a term first', 'Choose a term before releasing results.', 'warning');
        return;
    }

    $.post('admin/core/release_exam_results.php', { term: currentTerm }, function (response) {
        if (response.success) {
            releaseStatus = true;
            updateCounts();
            Swal.fire('Results released', response.message, 'success');
            return;
        }
        Swal.fire('Release blocked', response.message, 'warning');
    }, 'json').fail(function () {
        Swal.fire('Unable to release', 'The release request failed. Please try again.', 'error');
    });
});

$(function () {
    renderSubjectPool();
    renderSlots();
    currentTerm = $('#termSelect').val();
    loadSchedule();
});
</script>
</body>
</html>
