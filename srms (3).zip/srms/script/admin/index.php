<?php
chdir('../');
session_start();
require_once('db/config.php');
require_once('const/school.php');
require_once('const/check_session.php');
require_once('const/academic_dashboard.php');

// Allow access for admin (0) and exam officer (4)
if ($res == "1" && ($level == "0" || $level == "4")) {
    // Allow access for admin (0) and exam officer (4)
} else {
    header("location:../");
}

// Optional: Set a role title for display
$role_title = "Administrator";
if ($level == "4") {
    $role_title = "Exam Officer";
}
?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
<title>Borana University - Dashboard</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<base href="../">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link rel="icon" href="images/icon.ico">
<link rel="stylesheet" type="text/css" href="cdn.jsdelivr.net/npm/bootstrap-icons%401.10.5/font/bootstrap-icons.css">
<link type="text/css" rel="stylesheet" href="loader/waitMe.css">
</head>
<body class="app sidebar-mini">

<header class="app-header"><a class="app-header__logo" href="javascript:void(0);">
<img src="images/logo/<?php echo WBLogo; ?>" alt="<?php echo WBName; ?> logo">
<span><?php echo WBName; ?></span>
</a>
<a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>

<ul class="app-nav">

<li class="dropdown"><a class="app-nav__item" href="#" data-bs-toggle="dropdown" aria-label="Open Profile Menu"><i class="bi bi-person fs-4"></i></a>
<ul class="dropdown-menu settings-menu dropdown-menu-right">
<li><a class="dropdown-item" href="admin/profile"><i class="bi bi-person me-2 fs-5"></i> Profile</a></li>
<li><a class="dropdown-item" href="logout"><i class="bi bi-box-arrow-right me-2 fs-5"></i> Logout</a></li>
</ul>
</li>
</ul>
</header>

<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
<div class="app-sidebar__user">
<div>
<p class="app-sidebar__user-name"><?php echo $fname.' '.$lname; ?></p>
<p class="app-sidebar__user-designation"><?php echo $role_title; ?></p>
</div>
</div>
<ul class="app-menu">
<li><a class="app-menu__item active" href="admin"><i class="app-menu__icon feather icon-monitor"></i><span class="app-menu__label">Dashboard</span></a></li>

<!-- Admin-only menu items -->
<?php if ($level == "0"): ?>
<li><a class="app-menu__item" href="admin/academic"><i class="app-menu__icon feather icon-user"></i><span class="app-menu__label">Academic Account</span></a></li>
<li><a class="app-menu__item" href="admin/teachers"><i class="app-menu__icon feather icon-user"></i><span class="app-menu__label">Teachers</span></a></li>
<?php endif; ?>

<!-- Menu items for both Admin and Exam Officer -->
<li class="treeview"><a class="app-menu__item" href="javascript:void(0);" data-toggle="treeview"><i class="app-menu__icon feather icon-users"></i><span class="app-menu__label">Students</span><i class="treeview-indicator bi bi-chevron-right"></i></a>
<ul class="treeview-menu">
<li><a class="treeview-item" href="admin/register_students"><i class="icon bi bi-circle-fill"></i> Register Students</a></li>
<li><a class="treeview-item" href="admin/import_students"><i class="icon bi bi-circle-fill"></i> Import Students</a></li>
<li><a class="treeview-item" href="admin/manage_students"><i class="icon bi bi-circle-fill"></i> Manage Students</a></li>
</ul>
</li>

<!-- Exam management for Admin and Exam Officer -->
<?php if ($level == "0" || $level == "4"): ?>
<li><a class="app-menu__item" href="admin/exams"><i class="app-menu__icon feather icon-file-text"></i><span class="app-menu__label">Exam Management</span></a></li>
<?php endif; ?>

<!-- Admin-only settings -->
<?php if ($level == "0"): ?>
<li><a class="app-menu__item" href="admin/report"><i class="app-menu__icon feather icon-bar-chart-2"></i><span class="app-menu__label">Report Tool</span></a></li>
<li><a class="app-menu__item" href="admin/smtp"><i class="app-menu__icon feather icon-mail"></i><span class="app-menu__label">SMTP Settings</span></a></li>
<li><a class="app-menu__item" href="admin/system"><i class="app-menu__icon feather icon-settings"></i><span class="app-menu__label">System Settings</span></a></li>
<?php endif; ?>
</ul>
</aside>
<main class="app-content">
<div class="app-title">
<div>
<p class="dashboard-eyebrow">Borana University <?php echo $role_title; ?> Portal</p>
<h1>Academic Operations Dashboard</h1>
<p>Welcome back, <?php echo $fname.' '.$lname; ?>. Manage the university's student records, academic settings, and reports from one professional dashboard.</p>
</div>
<div class="dashboard-title-actions">
<div class="dashboard-badge">
<span>Student ID Format</span>
<strong>BRU/R/123/2016</strong>
</div>
</div>
</div>

<div class="dashboard-hero">
<div>
<p class="dashboard-eyebrow">At a glance</p>
<h2>Keep the university running smoothly with instant access to key academic data.</h2>
<p>Track active academic terms, monitor teaching and student records, and review subject coverage across the institution with a clean, responsive overview.</p>
</div>
<div class="dashboard-hero-points">
<div><i class="bi bi-mortarboard"></i><span>University-ready student records</span></div>
<div><i class="bi bi-graph-up-arrow"></i><span>Fast reporting and exports</span></div>
<div><i class="bi bi-gear-wide-connected"></i><span>Modern system controls</span></div>
</div>
</div>

<div class="row dashboard-metrics">
<div class="col-md-6 col-lg-3">
<a class="dashboard-metric-card" href="admin/academic" aria-label="Open Academic Terms overview">
<div class="widget-small primary coloured-icon"><i class="icon feather icon-folder fs-1"></i>
<div class="info">
<h4>Academic Terms</h4>
<p><b><?php echo number_format($academic_terms); ?></b></p>
</div>
</div>
<p class="dashboard-card-text">Manage the current academic terms and review the university term structure.</p>
</a>
</div>
<div class="col-md-6 col-lg-3">
<a class="dashboard-metric-card" href="admin/teachers" aria-label="Open Teachers overview">
<div class="widget-small primary coloured-icon"><i class="icon feather icon-user fs-1"></i>
<div class="info">
<h4>Teachers</h4>
<p><b><?php echo number_format($teachers); ?></b></p>
</div>
</div>
<p class="dashboard-card-text">View and manage the teaching staff assigned to Borana University.</p>
</a>
</div>
<div class="col-md-6 col-lg-3">
<a class="dashboard-metric-card" href="admin/manage_students" aria-label="Open Students overview">
<div class="widget-small primary coloured-icon"><i class="icon feather icon-users fs-1"></i>
<div class="info">
<h4>Students</h4>
<p><b><?php echo number_format($my_students); ?></b></p>
</div>
</div>
<p class="dashboard-card-text">Open student records, registration tools, and student management workflows.</p>
</a>
</div>
<div class="col-md-6 col-lg-3">
<a class="dashboard-metric-card" href="admin/report" aria-label="Open Subjects overview">
<div class="widget-small primary coloured-icon"><i class="icon feather icon-book-open fs-1"></i>
<div class="info">
<h4>Subjects</h4>
<p><b><?php echo number_format($subjects); ?></b></p>
</div>
</div>
<p class="dashboard-card-text">Review subject coverage and use reports linked to the university subject structure.</p>
</a>
</div>
</div>

</main>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>
<script src="loader/waitMe.js"></script>
<script src="js/forms.js"></script>
<script src="js/sweetalert2@11.js"></script>

</body>

</html>