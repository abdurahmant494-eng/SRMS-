<?php
$res = "0";
$authenticated = false;
$account_id = "";
$fname = "";
$lname = "";
$mname = "";
$email = "";
$level = "";
$img = "DEFAULT";

function normalize_session_ip($ip) {
    if ($ip === null) {
        return '';
    }

    $normalized = preg_replace('/^::ffff:(127\.0\.0\.1)$/i', '127.0.0.1', $ip);
    if ($normalized === '::1') {
        return '127.0.0.1';
    }

    return $normalized;
}

if(!isset($_COOKIE["__SRMS__logged"])) {
$res = "0";
} else {

if(!isset($_COOKIE["__SRMS__key"])) {
$res = "0";
}else{
$session_key = $_COOKIE["__SRMS__key"];
$current_ip = normalize_session_ip($_SERVER['REMOTE_ADDR']);

try {
$conn = new PDO('mysql:host='.DBHost.';dbname='.DBName.';charset='.DBCharset.';collation='.DBCollation.';prefix='.DBPrefix.'', DBUser, DBPass);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$stmt = $conn->prepare("SELECT * FROM tbl_login_sessions WHERE session_key = ?");
$stmt->execute([$session_key]);
$session_result = $stmt->fetchAll();

if (count($session_result) < 1) {
$res = "0";
}else{
$session_row = $session_result[0];
$session_ip = normalize_session_ip($session_row[3]);

if ($session_row[1] !== null) {
$stmt = $conn->prepare("SELECT * FROM tbl_staff WHERE id = ?");
$stmt->execute([$session_row[1]]);
$result = $stmt->fetchAll();

if (count($result) < 1) {
$res = "0";
}else{
$row = $result[0];
$account_id = $row[0];
$fname = $row[1];
$lname = $row[2];
$gender = $row[3];
$email = $row[4];
$login = $row[5];
$level = $row[6];
$status = $row[7];
$img = isset($row[8]) && $row[8] !== '' ? $row[8] : 'DEFAULT';
$authenticated = true;
}
} else {
$stmt = $conn->prepare("SELECT * FROM tbl_students WHERE id = ?");
$stmt->execute([$session_row[2]]);
$result = $stmt->fetchAll();

if (count($result) < 1) {
$res = "0";
}else{
$row = $result[0];
$account_id = $row[0];
$fname = $row[1];
$mname = $row[2];
$lname = $row[3];
$gender = $row[4];
$email = $row[5];
$class = $row[6];
$login = $row[7];
$level = $row[8];
$img = $row[9];
$status = $row[10];
$authenticated = true;

$stmt = $conn->prepare("SELECT * FROM tbl_classes WHERE id = ?");
$stmt->execute([$class]);
$class_result = $stmt->fetchAll();
$act_class = $class_result[0][1];
}
}

if ($authenticated) {
if ($current_ip == $session_ip) {
if ($status == "1") {
$res = "1";
}else{
$res = "2";
}
}else{
$res = "3";
}
}

}
}catch(PDOException $e)
{
echo "Connection failed: " . $e->getMessage();
}

}
}
?>
