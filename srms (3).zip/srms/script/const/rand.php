<?php
function GRS($length)
{
$stringSpace = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
$pieces = [];
$max = mb_strlen($stringSpace, '8bit') - 1;
for ($i = 0; $i < $length; ++ $i) {
$pieces[] = $stringSpace[random_int(0, $max)];
}
return implode('', $pieces);
}

function GP($length)
{
$stringSpace = '#@!0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
$pieces = [];
$max = mb_strlen($stringSpace, '8bit') - 1;
for ($i = 0; $i < $length; ++ $i) {
$pieces[] = $stringSpace[random_int(0, $max)];
}
return implode('', $pieces);
}

function normalize_student_id($raw_id, PDO $conn)
{
$raw_id = trim((string) $raw_id);

if ($raw_id !== '' && preg_match('/^BRU\/R\/\d{1,4}\/\d{4}$/', $raw_id)) {
$stmt = $conn->prepare("SELECT id FROM tbl_students WHERE id = ?");
$stmt->execute([$raw_id]);
if ($stmt->rowCount() === 0) {
return $raw_id;
}
}

$year = (int) date('Y');
$sequence = 1;

while (true) {
$candidate = 'BRU/R/' . str_pad((string) $sequence, 3, '0', STR_PAD_LEFT) . '/' . $year;
$stmt = $conn->prepare("SELECT id FROM tbl_students WHERE id = ?");
$stmt->execute([$candidate]);
if ($stmt->rowCount() === 0) {
return $candidate;
}
$sequence++;
}
}
?>
