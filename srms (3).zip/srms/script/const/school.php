<?php
try
{
$conn = new PDO('mysql:host='.DBHost.';dbname='.DBName.';charset='.DBCharset.';collation='.DBCollation.';prefix='.DBPrefix.'', DBUser, DBPass);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$stmt = $conn->prepare("SELECT * FROM tbl_school LIMIT 1");
$stmt->execute();
$result = $stmt->fetchAll();
foreach($result as $row)
{
DEFINE('WBName', $row[1]);
DEFINE('WBLogo', $row[2]);
DEFINE('WBResSys', $row[3]);
DEFINE('WBResAvi', $row[4]);
}

}catch(PDOException $e)
{
}

if (!function_exists('format_class_label')) {
    function format_class_label($name)
    {
        $name = trim((string) $name);

        if ($name === '') {
            return 'Class';
        }

        $base = trim(preg_replace('/\s*\b(19\d{2}|20\d{2})\b\s*$/i', '', $name));
        $base = preg_replace('/\s+/', ' ', $base);
        $base = ucwords(strtolower($base));
        $base = preg_replace_callback('/\(([^)]+)\)/', function ($match) {
            return '(' . trim(ucwords(strtolower($match[1]))) . ')';
        }, $base);
        $base = preg_replace('/\(\s+/', '(', $base);
        $base = preg_replace('/\s+\)/', ')', $base);

        if (preg_match('/^Form Two$/i', $base)) {
            $base = 'Form Two(Plant Science)';
        }

        if (preg_match('/^Form Four \(Science\)$/i', $base)) {
            $base = 'Form Four (Computer Science)';
        }

        if (preg_match('/^Form Three \(Arts\)$/i', $base)) {
            $base = 'Form Three (Arts)';
        }

        if (preg_match('/^Form Four \(Arts\)$/i', $base)) {
            $base = 'Form Four (Arts)';
        }

        if (preg_match('/^Form Three \(Science\)$/i', $base)) {
            $base = 'Form Three (Science)';
        }

        return $base . ' class of 2026';
    }
}

if (!function_exists('format_term_label')) {
    function format_term_label($name)
    {
        $name = trim((string) $name);

        if ($name === '') {
            return 'Term';
        }

        $lower = strtolower($name);

        if (strpos($lower, 'mid') !== false) {
            return 'Mid Term';
        }

        if (strpos($lower, 'final') !== false || strpos($lower, 'terminal') !== false || strpos($lower, 'annual') !== false) {
            return 'Final Term';
        }

        return ucwords(strtolower($name));
    }
}
?>
