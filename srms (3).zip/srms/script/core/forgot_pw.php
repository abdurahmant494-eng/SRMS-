<?php
session_start();
chdir('../');
require_once('db/config.php');
require_once('const/rand.php');
require_once('const/mail.php');
require_once('const/school.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'mail/src/Exception.php';
require 'mail/src/PHPMailer.php';
require 'mail/src/SMTP.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$_username = trim($_POST['username']);

if ($_username === '') {
    $_SESSION['reply'] = array (array("danger", "Please enter Email or Student ID"));
    header("location:../");
    exit;
}

try {
$conn = new PDO('mysql:host='.DBHost.';dbname='.DBName.';charset='.DBCharset.';collation='.DBCollation.';prefix='.DBPrefix.'', DBUser, DBPass);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$stmt = $conn->prepare("SELECT id, fname, email, level FROM tbl_staff WHERE LOWER(email) = LOWER(?) OR id = ?
UNION SELECT id, fname, email, level FROM tbl_students WHERE LOWER(email) = LOWER(?) OR id = ?");
$stmt->execute([$_username, $_username, $_username, $_username]);
$result = $stmt->fetchAll();

if (count($result) < 1) {
$_SESSION['reply'] = array (array("danger", "Account was not found"));
header("location:../");
}else{

foreach($result as $row)
{
$account = $row[0];
$name = $row[1];
$np = GP(8);
$email = $row[2];
$level = $row[3];
$npassword = password_hash($np, PASSWORD_DEFAULT);

$msg = "<h3 style='font-size:22px;'>Reset your password</h3> <p  style='font-size:20px;'>Hello $name! <br>
We received a request to change your password, Your new password is <b style='font-family:Courier New;'>$np</b><br><br>
</p>";

$mail = new PHPMailer;
$smtp_server = trim($smtp_server ?? '');
$smtp_username = trim($smtp_username ?? '');
$smtp_password = trim($smtp_password ?? '');
$smtp_conn_port = trim($smtp_conn_port ?? '');
$smtp_conn_type = trim($smtp_conn_type ?? '');

// Use SMTP only when server and port are configured.
$use_smtp = $smtp_server !== '' && $smtp_conn_port !== '';

if ($use_smtp) {
    $mail->SMTPOptions = array(
        'ssl' => array(
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true
        )
    );

    $mail->isSMTP();
    $mail->Host = $smtp_server;
    $mail->Hostname = $_SERVER['SERVER_NAME'] ?? 'localhost';
    $mail->SMTPAuth = $smtp_username !== '' && $smtp_password !== '';

    if ($mail->SMTPAuth) {
        $mail->Username = $smtp_username;
        $mail->Password = $smtp_password;
    }

    if ($smtp_conn_type !== '') {
        $mail->SMTPSecure = $smtp_conn_type;
    }

    $mail->Port = $smtp_conn_port;
}

$serverDomain = $_SERVER['SERVER_NAME'] ?? 'example.com';
$serverDomain = preg_replace('/[^a-zA-Z0-9\.\-]/', '', $serverDomain);
if (strpos($serverDomain, ':') !== false) {
    $serverDomain = explode(':', $serverDomain)[0];
}
if (!preg_match('/\./', $serverDomain)) {
    $serverDomain = 'example.com';
}

$fromAddress = filter_var($smtp_username, FILTER_VALIDATE_EMAIL) ? $smtp_username : 'no-reply@' . $serverDomain;
$mail->setFrom($fromAddress, WBName);
$mail->addAddress($email, $name);
$mail->isHTML(true);

$mail->Subject = 'Reset Password';
$mail->Body    = $msg;
$mail->AltBody = $msg;
// Attempt delivery: prefer SMTP, but fall back to PHP mail().
$subject = 'Reset Password';
$sent = false;
$send_method = '';

if ($use_smtp) {
    if ($mail->send()) {
        $sent = true;
        $send_method = 'smtp';
    } else {
        $er = $mail->ErrorInfo;
        // Try PHP mail() as a fallback
        if (function_exists('mail')) {
            $headers = "MIME-Version: 1.0\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8\r\n";
            $headers .= "From: " . $fromAddress . "\r\n";
            $sent = @mail($email, $subject, $msg, $headers);
            if ($sent) {
                $send_method = 'mail';
            }
        }

        if (!$sent) {
            // Neither SMTP nor mail() worked; do not change the user's password.
            $_SESSION['reply'] = array (array("danger", "SMTP failed: $er. Fallback mail() also failed. Password NOT changed. Please contact the system administrator."));
            header("location:../");
            exit;
        }
    }
} else {
    // No SMTP configured: try PHP mail() and update only if it succeeds.
    if (function_exists('mail')) {
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8\r\n";
        $headers .= "From: " . $fromAddress . "\r\n";
        $sent = @mail($email, $subject, $msg, $headers);
        if ($sent) {
            $send_method = 'mail';
        }
    }

    if (!$sent) {
        // No delivery method available. Do not change the password and inform user.
        $_SESSION['reply'] = array (array("danger", "No mail delivery available (SMTP not configured and PHP mail() failed). Password NOT changed. Please contact the system administrator."));
        header("location:../");
        exit;
    }
}

// If we reach here, email was sent via either SMTP or PHP mail(). Update the DB and inform the user.
if ($level < 3) {
    $stmt = $conn->prepare("UPDATE tbl_staff SET password = ? WHERE id = ?");
    $stmt->execute([$npassword, $account]);
} else {
    $stmt = $conn->prepare("UPDATE tbl_students SET password = ? WHERE id = ?");
    $stmt->execute([$npassword, $account]);
}

if ($send_method === 'smtp') {
    $_SESSION['reply'] = array (array("success", "Check $email for new password"));
} else {
    $_SESSION['reply'] = array (array("success", "Password reset and sent via PHP mail() to $email"));
}
header("location:../");

}


}

}catch(PDOException $e)
{
echo "Connection failed: " . $e->getMessage();
}

}else{
header("location:../");
}
?>
