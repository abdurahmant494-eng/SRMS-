<?php
chdir('../../');
session_start();
require_once('db/config.php');
require_once('const/check_session.php');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || $res != '1' || $level != '4') {
    header('location:../../');
    exit;
}

$term = isset($_POST['term']) ? (int)$_POST['term'] : 0;
$class_id = isset($_POST['class']) ? (int)$_POST['class'] : 0;
$subject_id = isset($_POST['subject']) ? (int)$_POST['subject'] : 0;
$start_date = isset($_POST['start_date']) ? trim($_POST['start_date']) : '';
$end_date = isset($_POST['end_date']) ? trim($_POST['end_date']) : '';
$status = isset($_POST['status']) ? trim($_POST['status']) : 'open';
$allowed_status = array('pending', 'open', 'closed', 'extended');

if ($term <= 0 || $class_id <= 0 || $subject_id <= 0 || $start_date === '' || $end_date === '' || !in_array($status, $allowed_status, true)) {
    $_SESSION['reply'] = array(array('danger', 'Please fill in all required grade submission window fields correctly.'));
    header('location:../grade_submission');
    exit;
}

try {
    $conn = new PDO('mysql:host='.DBHost.';dbname='.DBName.';charset='.DBCharset.';collation='.DBCollation.';prefix='.DBPrefix.'', DBUser, DBPass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $conn->exec("CREATE TABLE IF NOT EXISTS tbl_grade_submission_windows (
        id INT NOT NULL AUTO_INCREMENT,
        term_id INT NOT NULL,
        class_id INT NOT NULL,
        subject_id INT NOT NULL,
        start_date DATETIME NOT NULL,
        end_date DATETIME NOT NULL,
        status ENUM('pending','open','closed','extended') NOT NULL DEFAULT 'pending',
        opened_by INT NOT NULL,
        created_date DATETIME NOT NULL,
        PRIMARY KEY (id),
        KEY term_id (term_id),
        KEY class_id (class_id),
        KEY subject_id (subject_id),
        KEY opened_by (opened_by)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

    $stmt = $conn->prepare("SELECT COUNT(*) FROM tbl_grade_submission_windows WHERE term_id = ? AND class_id = ? AND subject_id = ? AND status IN ('open','pending')");
    $stmt->execute([$term, $class_id, $subject_id]);
    $exists = (int)$stmt->fetchColumn();

    if ($exists > 0) {
        $_SESSION['reply'] = array(array('danger', 'There is already an open or pending submission window for the same term, class, and subject.'));
        header('location:../grade_submission');
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO tbl_grade_submission_windows (term_id, class_id, subject_id, start_date, end_date, status, opened_by, created_date) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
    $stmt->execute([$term, $class_id, $subject_id, $start_date, $end_date, $status, $account_id]);

    $_SESSION['reply'] = array(array('success', 'Grade submission window opened successfully.'));
    header('location:../grade_submission');
} catch (PDOException $e) {
    $_SESSION['reply'] = array(array('danger', 'Database error: ' . $e->getMessage()));
    header('location:../grade_submission');
}
