<?php
chdir('../../');
session_start();
require_once('db/config.php');
require_once('const/check_session.php');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || $res != '1' || $level != '4') {
    header('location:../../');
    exit;
}

$exam_schedule_id = isset($_POST['exam_schedule_id']) ? (int)$_POST['exam_schedule_id'] : 0;
$teacher_id = isset($_POST['teacher_id']) ? (int)$_POST['teacher_id'] : 0;
$duty_type = isset($_POST['duty_type']) ? trim($_POST['duty_type']) : 'assistant';
$status = isset($_POST['status']) ? trim($_POST['status']) : 'assigned';
$allowed_duties = array('chief', 'assistant', 'supervisor');
$allowed_status = array('assigned', 'confirmed', 'completed');

if ($exam_schedule_id <= 0 || $teacher_id <= 0 || !in_array($duty_type, $allowed_duties, true) || !in_array($status, $allowed_status, true)) {
    $_SESSION['reply'] = array(array('danger', 'Please complete the invigilation assignment form correctly.'));
    header('location:../invigilation');
    exit;
}

try {
    $conn = new PDO('mysql:host='.DBHost.';dbname='.DBName.';charset='.DBCharset.';collation='.DBCollation.';prefix='.DBPrefix.'', DBUser, DBPass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $conn->exec("CREATE TABLE IF NOT EXISTS tbl_invigilators (
        id INT NOT NULL AUTO_INCREMENT,
        exam_schedule_id INT NOT NULL,
        teacher_id INT NOT NULL,
        assigned_by INT NOT NULL,
        assignment_date DATETIME NOT NULL,
        duty_type ENUM('chief','assistant','supervisor') NOT NULL DEFAULT 'assistant',
        status ENUM('assigned','confirmed','completed') NOT NULL DEFAULT 'assigned',
        PRIMARY KEY (id),
        KEY exam_schedule_id (exam_schedule_id),
        KEY teacher_id (teacher_id),
        KEY assigned_by (assigned_by)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

    $stmt = $conn->prepare("SELECT COUNT(*) FROM tbl_invigilators WHERE exam_schedule_id = ? AND teacher_id = ?");
    $stmt->execute([$exam_schedule_id, $teacher_id]);
    $exists = (int)$stmt->fetchColumn();

    if ($exists > 0) {
        $_SESSION['reply'] = array(array('danger', 'This teacher is already assigned to that exam schedule.'));
        header('location:../invigilation');
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO tbl_invigilators (exam_schedule_id, teacher_id, assigned_by, assignment_date, duty_type, status) VALUES (?, ?, ?, NOW(), ?, ?)");
    $stmt->execute([$exam_schedule_id, $teacher_id, $account_id, $duty_type, $status]);

    $_SESSION['reply'] = array(array('success', 'Invigilation assignment created successfully.'));
    header('location:../invigilation');
} catch (PDOException $e) {
    $_SESSION['reply'] = array(array('danger', 'Database error: ' . $e->getMessage()));
    header('location:../invigilation');
}
