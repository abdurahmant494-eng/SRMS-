<?php
chdir('../../');
session_start();
require_once('db/config.php');
require_once('const/check_session.php');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || $res != '1' || $level != '4') {
    header('location:../../');
    exit;
}

$exam_schedule_id = isset($_POST['exam_schedule_id']) ? (int)$_POST['exam_schedule_id'] : 0;
$attendance = isset($_POST['attendance']) && is_array($_POST['attendance']) ? $_POST['attendance'] : [];

if ($exam_schedule_id <= 0 || count($attendance) === 0) {
    $_SESSION['reply'] = array(array('danger', 'Please select an exam schedule and mark attendance.'));
    header('location:../reports/attendance'.($exam_schedule_id ? '?schedule_id='.$exam_schedule_id : ''));
    exit;
}

try {
    $conn = new PDO('mysql:host='.DBHost.';dbname='.DBName.';charset='.DBCharset.';collation='.DBCollation.';prefix='.DBPrefix.'', DBUser, DBPass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $conn->exec("CREATE TABLE IF NOT EXISTS tbl_exam_attendance (
        id INT NOT NULL AUTO_INCREMENT,
        exam_schedule_id INT NOT NULL,
        student_id INT NOT NULL,
        status ENUM('present','absent') NOT NULL DEFAULT 'present',
        recorded_by INT NOT NULL,
        recorded_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY uniq_exam_student (exam_schedule_id, student_id),
        KEY idx_exam_schedule (exam_schedule_id),
        KEY idx_student (student_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

    $selectStmt = $conn->prepare("SELECT COUNT(*) FROM tbl_students WHERE id = ?");
    $insertStmt = $conn->prepare("INSERT INTO tbl_exam_attendance (exam_schedule_id, student_id, status, recorded_by, recorded_at) VALUES (?, ?, ?, ?, NOW())");
    $updateStmt = $conn->prepare("UPDATE tbl_exam_attendance SET status = ?, recorded_by = ?, recorded_at = NOW() WHERE exam_schedule_id = ? AND student_id = ?");
    $existStmt = $conn->prepare("SELECT COUNT(*) FROM tbl_exam_attendance WHERE exam_schedule_id = ? AND student_id = ?");

    foreach ($attendance as $student_id => $status) {
        $student_id = (int)$student_id;
        $status = $status === 'present' ? 'present' : 'absent';
        if ($student_id <= 0) {
            continue;
        }

        $selectStmt->execute([$student_id]);
        if ((int)$selectStmt->fetchColumn() === 0) {
            continue;
        }

        $existStmt->execute([$exam_schedule_id, $student_id]);
        $exists = (int)$existStmt->fetchColumn();

        if ($exists > 0) {
            $updateStmt->execute([$status, $account_id, $exam_schedule_id, $student_id]);
        } else {
            $insertStmt->execute([$exam_schedule_id, $student_id, $status, $account_id]);
        }
    }

    $_SESSION['reply'] = array(array('success', 'Attendance records saved successfully.'));
    header('location:../reports/attendance?schedule_id='.$exam_schedule_id);
} catch (PDOException $e) {
    $_SESSION['reply'] = array(array('danger', 'Database error: '.$e->getMessage()));
    header('location:../reports/attendance?schedule_id='.$exam_schedule_id);
}
