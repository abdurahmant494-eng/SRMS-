<?php
chdir('../../');
session_start();
require_once('db/config.php');
require_once('const/check_session.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$fname = ucfirst($_POST['fname']);
$lname = ucfirst($_POST['lname']);
$email = $_POST['email'];
$gender = $_POST['gender'];
$id = $account_id;
$old_photo = isset($_POST['old_photo']) ? $_POST['old_photo'] : 'DEFAULT';
$img = $old_photo;
$upload_dir = 'images/staff/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] === UPLOAD_ERR_OK) {
    $photo = $_FILES['profile_photo'];
    $extension = strtolower(pathinfo($photo['name'], PATHINFO_EXTENSION));
    $allowed = ['png', 'jpg', 'jpeg'];

    if (!in_array($extension, $allowed)) {
        $_SESSION['reply'] = array (array('warning','Invalid profile photo format. Please upload PNG or JPG.'));
        header('location:../profile');
        exit;
    }

    $new_filename = uniqid('staff_', true).'.'.$extension;
    $destination = $upload_dir.$new_filename;

    if (move_uploaded_file($photo['tmp_name'], $destination)) {
        if ($old_photo !== 'DEFAULT' && file_exists($upload_dir.$old_photo)) {
            unlink($upload_dir.$old_photo);
        }
        $img = $new_filename;
    } else {
        $_SESSION['reply'] = array (array('warning','Unable to upload profile photo.'));
        header('location:../profile');
        exit;
    }
}

try {
$conn = new PDO('mysql:host='.DBHost.';dbname='.DBName.';charset='.DBCharset.';collation='.DBCollation.';prefix='.DBPrefix.'', DBUser, DBPass);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$columnCheck = $conn->prepare("SHOW COLUMNS FROM tbl_staff LIKE 'display_image'");
$columnCheck->execute();
if ($columnCheck->rowCount() === 0) {
    $conn->exec("ALTER TABLE tbl_staff ADD COLUMN display_image varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'DEFAULT' AFTER status");
}

$stmt = $conn->prepare("SELECT email FROM tbl_staff WHERE email = ? AND id != ? UNION SELECT email FROM tbl_students WHERE email = ? AND id != ?");
$stmt->execute([$email, $id, $email, $id]);
$result = $stmt->fetchAll();

if (count($result) > 0) {
$_SESSION['reply'] = array (array("error",'Email is already added'));
header("location:../profile");
}else{

$stmt = $conn->prepare("UPDATE tbl_staff SET fname=?, lname=?, gender=?, email=?, status=?, display_image=? WHERE id = ?");
$stmt->execute([$fname, $lname, $gender, $email, $status, $img, $id]);

$_SESSION['reply'] = array (array("success",'Profile updated successfully'));
header("location:../profile");
}

}catch(PDOException $e)
{
echo "Connection failed: " . $e->getMessage();
}

}else{
header("location:../");
}
