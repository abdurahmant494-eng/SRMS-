<?php
header('Location: exam_list.php');
exit;
