<?php
chdir('../');
session_start();
require_once('db/config.php');
require_once('const/school.php');
require_once('const/check_session.php');

if ($res != '1' || $level != '4') {
    header('location:../');
    exit;
}

$window = null;
$windows = [];
$terms = [];
$classes = [];
$subjects = [];

try {
    $conn = new PDO('mysql:host='.DBHost.';dbname='.DBName.';charset='.DBCharset.';collation='.DBCollation.';prefix='.DBPrefix.'', DBUser, DBPass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $window_id = isset($_GET['window_id']) ? (int)$_GET['window_id'] : 0;
    $has_grade_windows = (bool)$conn->query("SHOW TABLES LIKE 'tbl_grade_submission_windows'")->fetchColumn();

    if ($has_grade_windows && $window_id > 0) {
        $stmt = $conn->prepare("
            SELECT gsw.*, s.name AS subject_name, c.name AS class_name, t.name AS term_name,
            (SELECT COUNT(*) FROM tbl_exam_results WHERE subject_combination = gsw.subject_id AND class = gsw.class_id AND term = gsw.term_id) as submissions_count,
            (SELECT COUNT(*) FROM tbl_students WHERE class = gsw.class_id) as total_students
            FROM tbl_grade_submission_windows gsw
            INNER JOIN tbl_subjects s ON gsw.subject_id = s.id
            INNER JOIN tbl_classes c ON gsw.class_id = c.id
            INNER JOIN tbl_terms t ON gsw.term_id = t.id
            WHERE gsw.id = ?
        ");
        $stmt->execute([$window_id]);
        $window = $stmt->fetch(PDO::FETCH_ASSOC);
    }

    if ($has_grade_windows) {
        $stmt_windows = $conn->prepare("
            SELECT gsw.*, s.name as subject_name, c.name as class_name, t.name as term_name,
            (SELECT COUNT(*) FROM tbl_exam_results WHERE subject_combination = gsw.subject_id AND class = gsw.class_id AND term = gsw.term_id) as submissions_count,
            (SELECT COUNT(*) FROM tbl_students WHERE class = gsw.class_id) as total_students
            FROM tbl_grade_submission_windows gsw
            INNER JOIN tbl_subjects s ON gsw.subject_id = s.id
            INNER JOIN tbl_classes c ON gsw.class_id = c.id
            INNER JOIN tbl_terms t ON gsw.term_id = t.id
            WHERE gsw.status IN ('open', 'pending')
            ORDER BY gsw.end_date ASC
        ");
        $stmt_windows->execute();
        $windows = $stmt_windows->fetchAll(PDO::FETCH_ASSOC);
    }

    $terms = $conn->query("SELECT id, name FROM tbl_terms ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
    $classes = $conn->query("SELECT id, name FROM tbl_classes ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
    $subjects = $conn->query("SELECT id, name FROM tbl_subjects ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $window = null;
    $windows = [];
    $terms = [];
    $classes = [];
    $subjects = [];
}

$role_title = 'Exam Officer';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Borana University - Grade Submission</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<base href="../">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link rel="icon" href="images/icon.ico">
<link rel="stylesheet" type="text/css" href="cdn.jsdelivr.net/npm/bootstrap-icons%401.10.5/font/bootstrap-icons.css">
<link type="text/css" rel="stylesheet" href="loader/waitMe.css">
</head>
<body class="app sidebar-mini">
<header class="app-header"><a class="app-header__logo" href="javascript:void(0);">
<img src="images/logo/<?php echo WBLogo; ?>" alt="<?php echo WBName; ?> logo">
<span><?php echo WBName; ?></span>
</a>
<a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
<ul class="app-nav">
<li class="dropdown"><a class="app-nav__item" href="#" data-bs-toggle="dropdown" aria-label="Open Profile Menu"><i class="bi bi-person fs-4"></i></a>
<ul class="dropdown-menu settings-menu dropdown-menu-right">
<li><a class="dropdown-item" href="exam_officer/profile"><i class="bi bi-person me-2 fs-5"></i> My Profile</a></li>
<li><a class="dropdown-item" href="exam_officer/settings"><i class="bi bi-gear me-2 fs-5"></i> Settings</a></li>
<li><a class="dropdown-item" href="logout"><i class="bi bi-box-arrow-right me-2 fs-5"></i> Logout</a></li>
</ul></li>
</ul>
</header>
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
<div class="app-sidebar__user">
<div>
<p class="app-sidebar__user-name"><?php echo $fname.' '.$lname; ?></p>
<p class="app-sidebar__user-designation"><?php echo $role_title; ?></p>
</div>
</div>
<ul class="app-menu">
<li><a class="app-menu__item" href="exam_officer"><i class="app-menu__icon feather icon-monitor"></i><span class="app-menu__label">Dashboard</span></a></li>
<li><a class="app-menu__item" href="exam_officer/exam_scheduler"><i class="app-menu__icon feather icon-calendar"></i><span class="app-menu__label">Exam Scheduler</span></a></li>
<li><a class="app-menu__item active" href="exam_officer/grade_submission"><i class="app-menu__icon feather icon-upload"></i><span class="app-menu__label">Grade Submission</span></a></li>
<li><a class="app-menu__item" href="exam_officer/result_processing"><i class="app-menu__icon feather icon-bar-chart-2"></i><span class="app-menu__label">Result Processing</span></a></li>
<li><a class="app-menu__item" href="exam_officer/invigilation"><i class="app-menu__icon feather icon-users"></i><span class="app-menu__label">Invigilation Duty</span></a></li>
<li class="treeview"><a class="app-menu__item" href="javascript:void(0);" data-toggle="treeview"><i class="app-menu__icon feather icon-file-text"></i><span class="app-menu__label">Reports</span><i class="treeview-indicator bi bi-chevron-right"></i></a>
<ul class="treeview-menu">
<li><a class="treeview-item" href="exam_officer/reports/result_slips">Result Slips</a></li>
<li><a class="treeview-item" href="exam_officer/reports/transcripts">Transcripts</a></li>
<li><a class="treeview-item" href="exam_officer/reports/attendance">Exam Attendance</a></li>
</ul></li>
<li><a class="app-menu__item" href="exam_officer/analytics"><i class="app-menu__icon feather icon-pie-chart"></i><span class="app-menu__label">Analytics</span></a></li>
</ul>
</aside>
<main class="app-content">
<div class="app-title">
<div>
<p class="dashboard-eyebrow">Borana University Exam Operations</p>
<h1>Grade Submission</h1>
<p>Monitor the current grade submission windows and review the status of teacher submissions.</p>
</div>
</div>

<div class="row mb-4">
    <div class="col-md-12">
        <div class="tile">
            <h3 class="tile-title"><i class="bi bi-plus-circle me-2"></i>Create Grade Submission Window</h3>
            <form class="app_frm row g-3" action="exam_officer/core/create_grade_window" method="POST" autocomplete="off">
                <div class="col-md-3">
                    <label class="form-label">Term</label>
                    <select class="form-control" name="term" required>
                        <option value="">Select Term</option>
                        <?php foreach ($terms as $term): ?>
                        <option value="<?php echo (int)$term['id']; ?>"><?php echo htmlspecialchars($term['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Class</label>
                    <select class="form-control" name="class" required>
                        <option value="">Select Class</option>
                        <?php foreach ($classes as $class): ?>
                        <option value="<?php echo (int)$class['id']; ?>"><?php echo htmlspecialchars($class['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Subject</label>
                    <select class="form-control" name="subject" required>
                        <option value="">Select Subject</option>
                        <?php foreach ($subjects as $subject): ?>
                        <option value="<?php echo (int)$subject['id']; ?>"><?php echo htmlspecialchars($subject['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Window Status</label>
                    <select class="form-control" name="status" required>
                        <option value="open">Open</option>
                        <option value="pending">Pending</option>
                        <option value="closed">Closed</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Start Date / Time</label>
                    <input type="datetime-local" class="form-control" name="start_date" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">End Date / Time</label>
                    <input type="datetime-local" class="form-control" name="end_date" required>
                </div>
                <div class="col-md-4 d-flex align-items-end">
                    <button type="submit" class="btn btn-success w-100">Open Window</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($window):
$progress = $window['total_students'] > 0 ? round(($window['submissions_count'] / $window['total_students']) * 100) : 0;
?>
<div class="row">
<div class="col-md-12">
<div class="tile">
<h3 class="tile-title"><i class="bi bi-search me-2"></i>Selected Window Details</h3>
<div class="row">
<div class="col-md-6">
<p><strong>Subject:</strong> <?php echo htmlspecialchars($window['subject_name']); ?></p>
<p><strong>Class:</strong> <?php echo htmlspecialchars($window['class_name']); ?></p>
<p><strong>Term:</strong> <?php echo htmlspecialchars($window['term_name']); ?></p>
<p><strong>Status:</strong> <span class="badge bg-<?php echo $window['status'] == 'open' ? 'success' : 'warning'; ?>"><?php echo ucfirst($window['status']); ?></span></p>
</div>
<div class="col-md-6">
<p><strong>Window:</strong> <?php echo date('d M Y H:i', strtotime($window['start_date'])); ?> to <?php echo date('d M Y H:i', strtotime($window['end_date'])); ?></p>
<p><strong>Submitted:</strong> <?php echo (int)$window['submissions_count']; ?> / <?php echo (int)$window['total_students']; ?></p>
<div class="progress" style="height: 24px;">
<div class="progress-bar" role="progressbar" style="width: <?php echo $progress; ?>%;" aria-valuenow="<?php echo $progress; ?>" aria-valuemin="0" aria-valuemax="100">
<?php echo $progress; ?>%
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<?php endif; ?>

<div class="row mt-4">
<div class="col-md-12">
<div class="tile">
<h3 class="tile-title"><i class="bi bi-list-check me-2"></i>Grade Submission Windows</h3>
<div class="table-responsive">
<table class="table table-hover">
<thead>
<tr>
<th>Subject</th>
<th>Class</th>
<th>Term</th>
<th>Window</th>
<th>Status</th>
<th>Progress</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php if (count($windows) > 0): foreach ($windows as $row): $progress = $row['total_students'] > 0 ? round(($row['submissions_count'] / $row['total_students']) * 100) : 0; ?>
<tr>
<td><?php echo htmlspecialchars($row['subject_name']); ?></td>
<td><?php echo htmlspecialchars($row['class_name']); ?></td>
<td><?php echo htmlspecialchars($row['term_name']); ?></td>
<td><?php echo date('d M Y', strtotime($row['start_date'])); ?> - <?php echo date('d M Y', strtotime($row['end_date'])); ?></td>
<td><span class="badge bg-<?php echo $row['status'] == 'open' ? 'success' : 'warning'; ?>"><?php echo ucfirst($row['status']); ?></span></td>
<td>
<div class="progress" style="height: 18px;">
<div class="progress-bar" role="progressbar" style="width: <?php echo $progress; ?>%;" aria-valuenow="<?php echo $progress; ?>" aria-valuemin="0" aria-valuemax="100"><?php echo $row['submissions_count']; ?>/<?php echo $row['total_students']; ?></div>
</div>
</td>
<td><a href="exam_officer/grade_submission?window_id=<?php echo (int)$row['id']; ?>" class="btn btn-sm btn-primary">Monitor</a></td>
</tr>
<?php endforeach; else: ?>
<tr><td colspan="7" class="text-center">No active grade submission windows found.</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</main>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>
<script src="loader/waitMe.js"></script>
<script src="js/forms.js"></script>
<script src="js/sweetalert2@11.js"></script>
<?php require_once('const/check-reply.php'); ?>
</body>
</html>
