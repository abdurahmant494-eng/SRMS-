<?php
chdir('../');
session_start();
require_once('db/config.php');
require_once('const/school.php');
require_once('const/check_session.php');
require_once('const/academic_dashboard.php');

// Exam Officer access level check (level 4)
if ($res == "1" && $level == "4") {
    // Additional exam-specific data queries
    $current_term_name = 'Current Term';
    $total_exams = 0;
    $pending_exams = 0;
    $published_results = 0;
    $invigilation_assignments = 0;
    $pending_grade_submissions = 0;
    $upcoming_exams = 0;
    $today_exams = 0;
    $upcoming_list = [];

    try {
        $stmt_active_term = $conn->prepare("SELECT id, name FROM tbl_terms WHERE status = 1 ORDER BY id DESC LIMIT 1");
        $stmt_active_term->execute();
        $active_term = $stmt_active_term->fetch(PDO::FETCH_ASSOC);
        if ($active_term) {
            $current_term_name = $active_term['name'];
        }

        $today = date('Y-m-d');
        $total_exams = (int)$conn->query("SELECT COUNT(*) FROM tbl_exam_schedules")->fetchColumn();

        $has_status = (bool)$conn->query("SHOW COLUMNS FROM tbl_exam_schedules LIKE 'status'")->fetchColumn();
        $pending_exams = $has_status ? (int)$conn->query("SELECT COUNT(*) FROM tbl_exam_schedules WHERE status IN ('pending','scheduled')")->fetchColumn() : 0;

        $published_results = 0;
        $has_releases = (bool)$conn->query("SHOW TABLES LIKE 'tbl_exam_releases'")->fetchColumn();
        if ($has_releases) {
            $published_results = (int)$conn->query("SELECT COUNT(*) FROM tbl_exam_releases WHERE released = 1")->fetchColumn();
        } else {
            $published_results = (int)$conn->query("SELECT COUNT(*) FROM tbl_exam_results")->fetchColumn();
        }

        $has_invigilators = (bool)$conn->query("SHOW TABLES LIKE 'tbl_invigilators'")->fetchColumn();
        $invigilation_assignments = 0;
        if ($has_invigilators) {
            $stmt_invig = $conn->prepare("SELECT COUNT(*) FROM tbl_invigilators WHERE assigned_by = ?");
            $stmt_invig->execute([$account_id]);
            $invigilation_assignments = (int)$stmt_invig->fetchColumn();
        }

        $has_grade_windows = (bool)$conn->query("SHOW TABLES LIKE 'tbl_grade_submission_windows'")->fetchColumn();
        $pending_grade_submissions = $has_grade_windows ? (int)$conn->query("SELECT COUNT(*) FROM tbl_grade_submission_windows WHERE status IN ('open', 'pending')")->fetchColumn() : 0;

        $has_exam_date = (bool)$conn->query("SHOW COLUMNS FROM tbl_exam_schedules LIKE 'exam_date'")->fetchColumn();
        $has_subject_id = (bool)$conn->query("SHOW COLUMNS FROM tbl_exam_schedules LIKE 'subject_id'")->fetchColumn();
        $has_class_id = (bool)$conn->query("SHOW COLUMNS FROM tbl_exam_schedules LIKE 'class_id'")->fetchColumn();
        $has_term_id = (bool)$conn->query("SHOW COLUMNS FROM tbl_exam_schedules LIKE 'term_id'")->fetchColumn();

        $upcoming_exams = 0;
        $today_exams = 0;
        $upcoming_list = [];
        $upcoming_exams_label = 'Next 7 Days';

        if ($has_exam_date) {
            $stmt_upcoming = $conn->prepare("SELECT COUNT(*) FROM tbl_exam_schedules WHERE exam_date BETWEEN ? AND DATE_ADD(?, INTERVAL 7 DAY)");
            $stmt_upcoming->execute([$today, $today]);
            $upcoming_exams = (int)$stmt_upcoming->fetchColumn();

            $stmt_today = $conn->prepare("SELECT COUNT(*) FROM tbl_exam_schedules WHERE exam_date = ?");
            $stmt_today->execute([$today]);
            $today_exams = (int)$stmt_today->fetchColumn();

            $stmt_list = $conn->prepare("SELECT es.*, s.name AS subject_name, c.name AS class_name, t.name AS term_name
                FROM tbl_exam_schedules es
                LEFT JOIN tbl_subjects s ON es.subject_id = s.id
                LEFT JOIN tbl_classes c ON es.class_id = c.id
                LEFT JOIN tbl_terms t ON es.term_id = t.id
                WHERE es.exam_date BETWEEN ? AND DATE_ADD(?, INTERVAL 7 DAY)
                ORDER BY es.exam_date ASC
                LIMIT 10");
            $stmt_list->execute([$today, $today]);
            $upcoming_list = $stmt_list->fetchAll(PDO::FETCH_ASSOC);
        } else {
            $upcoming_exams_label = 'Current Term Schedule';

            if ($active_term && $has_term_id) {
                $stmt_upcoming = $conn->prepare("SELECT COUNT(*) FROM tbl_exam_schedules WHERE term = ?");
                $stmt_upcoming->execute([$active_term['id']]);
                $upcoming_exams = (int)$stmt_upcoming->fetchColumn();

                $subjectColumn = $has_subject_id ? 'subject_id' : 'subject';
                $subjectJoin = "LEFT JOIN tbl_subjects subj ON subj.id = es." . $subjectColumn;
                $classSelect = $has_class_id ? ', c.name AS class_name' : '';
                $classJoin = $has_class_id ? 'LEFT JOIN tbl_classes c ON c.id = es.class_id' : '';
                $termSelect = $has_term_id ? ', t.name AS term_name' : '';
                $termJoin = $has_term_id ? 'LEFT JOIN tbl_terms t ON t.id = es.term' : '';

                $stmt_list = $conn->prepare("SELECT es.id, es.slot_key, subj.name AS subject_name" . $classSelect . $termSelect . " FROM tbl_exam_schedules es " . $subjectJoin . " " . $classJoin . " " . $termJoin . " WHERE es.term = ? ORDER BY es.slot_key ASC LIMIT 10");
                $stmt_list->execute([$active_term['id']]);
                $upcoming_list = $stmt_list->fetchAll(PDO::FETCH_ASSOC);
            }
        }
    } catch (PDOException $e) {
        $current_term_name = 'Current Term';
        $total_exams = 0;
        $pending_exams = 0;
        $published_results = 0;
        $invigilation_assignments = 0;
        $pending_grade_submissions = 0;
        $upcoming_exams = 0;
        $today_exams = 0;
        $upcoming_list = [];
    }
} else {
    header("location:../");
    exit();
}

function formatScheduleSlotLabel($slotKey) {
    if (empty($slotKey)) {
        return 'TBD';
    }
    $parts = explode('_', $slotKey, 2);
    if (count($parts) !== 2) {
        return ucfirst(str_replace('_', ' ', $slotKey));
    }
    $day = ucfirst($parts[0]);
    $time = preg_replace('/(\d{2})(\d{2})$/', '$1:$2', $parts[1]);
    return trim($day . ' ' . $time);
}
?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
<title>Borana University - Exam Officer Dashboard</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<base href="../">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link rel="icon" href="images/icon.ico">
<link rel="stylesheet" type="text/css" href="cdn.jsdelivr.net/npm/bootstrap-icons%401.10.5/font/bootstrap-icons.css">
<link type="text/css" rel="stylesheet" href="loader/waitMe.css">
<style>
    .exam-warning {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 25px;
    }
    .exam-warning h5 {
        margin: 0 0 10px 0;
        font-weight: 600;
    }
    .exam-warning p {
        margin: 0;
        opacity: 0.95;
    }
    .quick-action-btn {
        transition: transform 0.2s;
        margin-bottom: 10px;
    }
    .quick-action-btn:hover {
        transform: translateY(-3px);
    }
    .metric-card {
        margin-bottom: 20px;
    }
    .status-badge {
        position: absolute;
        top: 10px;
        right: 10px;
        padding: 3px 8px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: bold;
    }
    .status-pending { background: #ffc107; color: #000; }
    .status-scheduled { background: #17a2b8; color: #fff; }
    .status-completed { background: #28a745; color: #fff; }
    .widget-small {
        position: relative;
        overflow: hidden;
    }
</style>
</head>
<body class="app sidebar-mini">

<header class="app-header"><a class="app-header__logo" href="javascript:void(0);">
<img src="images/logo/<?php echo WBLogo; ?>" alt="<?php echo WBName; ?> logo">
<span><?php echo WBName; ?></span>
</a>
<a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>

<ul class="app-nav">
<li class="dropdown"><a class="app-nav__item" href="#" data-bs-toggle="dropdown" aria-label="Open Profile Menu"><i class="bi bi-person fs-4"></i></a>
<ul class="dropdown-menu settings-menu dropdown-menu-right">
<li><a class="dropdown-item" href="exam_officer/profile"><i class="bi bi-person me-2 fs-5"></i> My Profile</a></li>
<li><a class="dropdown-item" href="exam_officer/settings"><i class="bi bi-gear me-2 fs-5"></i> Settings</a></li>
<li><hr class="dropdown-divider"></li>
<li><a class="dropdown-item" href="logout"><i class="bi bi-box-arrow-right me-2 fs-5"></i> Logout</a></li>
</ul>
</li>
</ul>
</header>

<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
<div class="app-sidebar__user">
<div>
<p class="app-sidebar__user-name"><?php echo $fname.' '.$lname; ?></p>
<p class="app-sidebar__user-designation">Exam Officer</p>
<p class="app-sidebar__user-designation" style="font-size: 11px; margin-top: 5px;">
    <i class="bi bi-calendar3"></i> <?php echo $current_term_name; ?>
</p>
</div>
</div>
<ul class="app-menu">
<li><a class="app-menu__item active" href="exam_officer"><i class="app-menu__icon feather icon-monitor"></i><span class="app-menu__label">Dashboard</span></a></li>
<li><a class="app-menu__item" href="exam_officer/exam_scheduler"><i class="app-menu__icon feather icon-calendar"></i><span class="app-menu__label">Exam Scheduler</span></a></li>
<li><a class="app-menu__item" href="exam_officer/exam_list"><i class="app-menu__icon feather icon-list"></i><span class="app-menu__label">Exam List</span></a></li>
<li><a class="app-menu__item" href="exam_officer/grade_submission"><i class="app-menu__icon feather icon-upload"></i><span class="app-menu__label">Grade Submission</span></a></li>
<li><a class="app-menu__item" href="exam_officer/result_processing"><i class="app-menu__icon feather icon-bar-chart-2"></i><span class="app-menu__label">Result Processing</span></a></li>
<li><a class="app-menu__item" href="exam_officer/invigilation"><i class="app-menu__icon feather icon-users"></i><span class="app-menu__label">Invigilation Duty</span></a></li>
<li class="treeview"><a class="app-menu__item" href="javascript:void(0);" data-toggle="treeview"><i class="app-menu__icon feather icon-file-text"></i><span class="app-menu__label">Reports</span><i class="treeview-indicator bi bi-chevron-right"></i></a>
<ul class="treeview-menu">
<li><a class="treeview-item" href="exam_officer/reports/result_slips"><i class="icon bi bi-circle-fill"></i> Result Slips</a></li>
<li><a class="treeview-item" href="exam_officer/reports/transcripts"><i class="icon bi bi-circle-fill"></i> Transcripts</a></li>
<li><a class="treeview-item" href="exam_officer/reports/analysis"><i class="icon bi bi-circle-fill"></i> Performance Analysis</a></li>
<li><a class="treeview-item" href="exam_officer/reports/attendance"><i class="icon bi bi-circle-fill"></i> Exam Attendance</a></li>
</ul>
</li>
<li><a class="app-menu__item" href="exam_officer/analytics"><i class="app-menu__icon feather icon-pie-chart"></i><span class="app-menu__label">Analytics</span></a></li>
</ul>
</aside>

<main class="app-content">
<div class="app-title">
<div>
<p class="dashboard-eyebrow">Borana University Exam Officer Portal</p>
<h1>Exam Officer Dashboard</h1>
<p>Welcome back, <?php echo $fname.' '.$lname; ?>. Monitor the examination workflow, academic coverage, and performance summaries from one clean dashboard.</p>
</div>
<div class="dashboard-title-actions">
<div class="dashboard-badge">
<span>Active Term</span>
<strong><?php echo $current_term_name; ?></strong>
</div>
</div>
</div>

<!-- Quick Warning/Alerts Section -->
<?php if ($pending_exams > 0): ?>
<div class="exam-warning">
    <div class="row align-items-center">
        <div class="col-md-8">
            <h5><i class="bi bi-exclamation-triangle-fill me-2"></i> Pending Exam Actions</h5>
            <p>You have <?php echo $pending_exams; ?> exam(s) awaiting scheduling or approval. Please review them soon.</p>
        </div>
        <div class="col-md-4 text-end">
            <a href="exam_officer/exam_scheduler" class="btn btn-light btn-sm">Review Now <i class="bi bi-arrow-right"></i></a>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if ($pending_grade_submissions > 0): ?>
<div class="exam-warning" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
    <div class="row align-items-center">
        <div class="col-md-8">
            <h5><i class="bi bi-clock-history me-2"></i> Grade Submission Windows Open</h5>
            <p><?php echo $pending_grade_submissions; ?> grade submission window(s) are currently open. Monitor teacher submissions.</p>
        </div>
        <div class="col-md-4 text-end">
            <a href="exam_officer/grade_submission" class="btn btn-light btn-sm">Monitor <i class="bi bi-arrow-right"></i></a>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="dashboard-hero">
<div>
<p class="dashboard-eyebrow">At a glance</p>
<h2>Keep exam operations organized with a focused view of terms, classes, teachers, and subjects.</h2>
<p>Use this dashboard as your daily command center for the current academic structure and exam-related oversight.</p>
</div>
<div class="dashboard-hero-points">
<div><i class="bi bi-clipboard-check"></i><span>Exam operations overview</span></div>
<div><i class="bi bi-graph-up-arrow"></i><span>Performance insights</span></div>
<div><i class="bi bi-mortarboard"></i><span>University academic structure</span></div>
</div>
</div>

<!-- Exam-Specific Metrics Row -->
<div class="row dashboard-metrics">
<div class="col-md-6 col-lg-3 metric-card">
    <div class="widget-small primary coloured-icon">
        <i class="icon feather icon-calendar fs-1"></i>
        <div class="info">
            <h4>Total Exams<br><small style="font-size: 11px;"><?php echo $current_term_name; ?></small></h4>
            <p><b><?php echo number_format($total_exams); ?></b></p>
        </div>
        <?php if ($total_exams > 0): ?>
        <a href="exam_officer/exam_list" class="stretched-link"></a>
        <?php endif; ?>
    </div>
</div>
<div class="col-md-6 col-lg-3 metric-card">
    <div class="widget-small primary coloured-icon">
        <i class="icon feather icon-clock fs-1"></i>
        <div class="info">
            <h4>Pending Exams</h4>
            <p><b><?php echo number_format($pending_exams); ?></b></p>
        </div>
        <?php if ($pending_exams > 0): ?>
        <span class="status-badge status-pending">Action Required</span>
        <?php endif; ?>
    </div>
</div>
<div class="col-md-6 col-lg-3 metric-card">
    <div class="widget-small primary coloured-icon">
        <i class="icon feather icon-award fs-1"></i>
        <div class="info">
            <h4>Results Published</h4>
            <p><b><?php echo number_format($published_results); ?></b></p>
        </div>
    </div>
</div>
<div class="col-md-6 col-lg-3 metric-card">
    <div class="widget-small primary coloured-icon">
        <i class="icon feather icon-users fs-1"></i>
        <div class="info">
            <h4>Invigilation<br><small style="font-size: 11px;">Assignments</small></h4>
            <p><b><?php echo number_format($invigilation_assignments); ?></b></p>
        </div>
    </div>
</div>
</div>

<!-- Second Row of Metrics -->
<div class="row dashboard-metrics mt-2">
<div class="col-md-6 col-lg-3 metric-card">
    <div class="widget-small primary coloured-icon">
        <i class="icon feather icon-upload-cloud fs-1"></i>
        <div class="info">
            <h4>Grade Submissions<br><small style="font-size: 11px;">Open Windows</small></h4>
            <p><b><?php echo number_format($pending_grade_submissions); ?></b></p>
        </div>
    </div>
</div>
<div class="col-md-6 col-lg-3 metric-card">
    <div class="widget-small primary coloured-icon">
        <i class="icon feather icon-bell fs-1"></i>
        <div class="info">
            <h4>Upcoming Exams<br><small style="font-size: 11px;"><?php echo htmlspecialchars($upcoming_exams_label); ?></small></h4>
            <p><b><?php echo number_format($upcoming_exams); ?></b></p>
        </div>
    </div>
</div>
<div class="col-md-6 col-lg-3 metric-card">
    <div class="widget-small primary coloured-icon">
        <i class="icon feather icon-sun fs-1"></i>
        <div class="info">
            <h4>Today's Exams</h4>
            <p><b><?php echo number_format($today_exams); ?></b></p>
        </div>
    </div>
</div>
<div class="col-md-6 col-lg-3 metric-card">
    <div class="widget-small primary coloured-icon">
        <i class="icon feather icon-folder fs-1"></i>
        <div class="info">
            <h4>Academic Terms</h4>
            <p><b><?php echo number_format($academic_terms); ?></b></p>
        </div>
    </div>
</div>
</div>

<!-- Basic Academic Structure Metrics -->
<div class="row dashboard-metrics mt-2">
<div class="col-md-6 col-lg-4">
<div class="widget-small primary coloured-icon"><i class="icon feather icon-user fs-1"></i>
<div class="info">
<h4>Teachers</h4>
<p><b><?php echo number_format($teachers); ?></b></p>
</div>
</div>
</div>
<div class="col-md-6 col-lg-4">
<div class="widget-small primary coloured-icon"><i class="icon feather icon-users fs-1"></i>
<div class="info">
<h4>Students</h4>
<p><b><?php echo number_format($my_students); ?></b></p>
</div>
</div>
</div>
<div class="col-md-6 col-lg-4">
<div class="widget-small primary coloured-icon"><i class="icon feather icon-book-open fs-1"></i>
<div class="info">
<h4>Subjects</h4>
<p><b><?php echo number_format($subjects); ?></b></p>
</div>
</div>
</div>
</div>

<!-- Quick Action Buttons for Exam Officer -->
<div class="row mt-4">
    <div class="col-md-12">
        <div class="tile">
            <h3 class="tile-title"><i class="bi bi-lightning-charge me-2"></i> Quick Actions</h3>
            <div class="row">
                <div class="col-md-3 col-sm-6 mb-2">
                    <a href="exam_officer/exam_scheduler" class="btn btn-primary w-100 quick-action-btn">
                        <i class="bi bi-calendar-plus me-2"></i> Schedule Exams
                    </a>
                </div>
                <div class="col-md-3 col-sm-6 mb-2">
                    <a href="exam_officer/grade_submission" class="btn btn-success w-100 quick-action-btn">
                        <i class="bi bi-upload me-2"></i> Open Grade Window
                    </a>
                </div>
                <div class="col-md-3 col-sm-6 mb-2">
                    <a href="exam_officer/result_processing" class="btn btn-info w-100 quick-action-btn text-white">
                        <i class="bi bi-graph-up me-2"></i> Process Results
                    </a>
                </div>
                <div class="col-md-3 col-sm-6 mb-2">
                    <a href="exam_officer/invigilation" class="btn btn-warning w-100 quick-action-btn">
                        <i class="bi bi-people me-2"></i> Assign Invigilators
                    </a>
                </div>
                <div class="col-md-3 col-sm-6 mb-2">
                    <a href="exam_officer/reports/result_slips" class="btn btn-secondary w-100 quick-action-btn">
                        <i class="bi bi-printer me-2"></i> Print Result Slips
                    </a>
                </div>
                <div class="col-md-3 col-sm-6 mb-2">
                    <a href="exam_officer/analytics" class="btn btn-dark w-100 quick-action-btn">
                        <i class="bi bi-graph-up me-2"></i> View Analytics
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Recent Activity / Upcoming Exams Table -->
<div class="row mt-4">
    <div class="col-md-12">
        <div class="tile">
            <h3 class="tile-title"><i class="bi bi-clock-history me-2"></i> Upcoming Exams<?php echo !empty($upcoming_exams_label) ? ' (' . htmlspecialchars($upcoming_exams_label) . ')' : ''; ?></h3>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Exam Name</th>
                            <th>Subject</th>
                            <th>Class</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Venue</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($upcoming_list) > 0): foreach ($upcoming_list as $exam): ?>
                        <tr>
                            <td><?php echo isset($exam['exam_name']) ? htmlspecialchars($exam['exam_name']) : 'Exam Schedule'; ?></td>
                            <td><?php echo isset($exam['subject_name']) ? htmlspecialchars($exam['subject_name']) : 'Pending subject mapping'; ?></td>
                            <td><?php echo isset($exam['class_name']) ? htmlspecialchars($exam['class_name']) : (isset($exam['slot_key']) ? 'N/A' : 'Pending class mapping'); ?></td>
                            <td><?php echo isset($exam['exam_date']) ? date('d M Y', strtotime($exam['exam_date'])) : htmlspecialchars(formatScheduleSlotLabel($exam['slot_key'] ?? '')); ?></td>
                            <td><?php echo isset($exam['start_time']) ? date('h:i A', strtotime($exam['start_time'])) . ' - ' . date('h:i A', strtotime($exam['end_time'])) : (isset($exam['slot_key']) ? 'Slot-based' : 'TBD'); ?></td>
                            <td><?php echo isset($exam['venue']) ? htmlspecialchars($exam['venue']) : (isset($exam['slot_key']) ? 'Draft slot' : 'To be assigned'); ?></td>
                            <td>
                                <span class="badge bg-info"><?php echo isset($exam['status']) ? ucfirst($exam['status']) : 'Scheduled'; ?></span>
                            </td>
                        </tr>
                        <?php endforeach; else: ?>
                        <tr>
                            <td colspan="7" class="text-center">No upcoming exams scheduled in the next 7 days</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php if (count($upcoming_list) > 0): ?>
            <div class="text-end mt-3">
                <a href="exam_officer/exam_list" class="btn btn-sm btn-outline-primary">View All Exams <i class="bi bi-arrow-right"></i></a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Grade Submission Status -->
<div class="row mt-4">
    <div class="col-md-12">
        <div class="tile">
            <h3 class="tile-title"><i class="bi bi-file-text me-2"></i> Grade Submission Status</h3>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Subject</th>
                            <th>Class</th>
                            <th>Term</th>
                            <th>Submission Window</th>
                            <th>Status</th>
                            <th>Submissions</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $windows = [];
                        try {
                            $has_grade_windows = (bool)$conn->query("SHOW TABLES LIKE 'tbl_grade_submission_windows'")->fetchColumn();
                            if ($has_grade_windows) {
                                $stmt_windows = $conn->prepare("
                                    SELECT gsw.*, s.name as subject_name, c.name as class_name, t.name as term_name,
                                    (SELECT COUNT(*) FROM tbl_exam_results WHERE subject_combination = gsw.subject_id AND class = gsw.class_id AND term = gsw.term_id) as submissions_count,
                                    (SELECT COUNT(*) FROM tbl_students WHERE class = gsw.class_id) as total_students
                                    FROM tbl_grade_submission_windows gsw
                                    INNER JOIN tbl_subjects s ON gsw.subject_id = s.id
                                    INNER JOIN tbl_classes c ON gsw.class_id = c.id
                                    INNER JOIN tbl_terms t ON gsw.term_id = t.id
                                    WHERE gsw.status IN ('open', 'pending')
                                    ORDER BY gsw.end_date ASC
                                    LIMIT 10
                                ");
                                $stmt_windows->execute();
                                $windows = $stmt_windows->fetchAll(PDO::FETCH_ASSOC);
                            }
                        } catch (PDOException $e) {
                            $windows = [];
                        }

                        if (count($windows) > 0):
                            foreach($windows as $window):
                                $progress = $window['total_students'] > 0 ? round(($window['submissions_count'] / $window['total_students']) * 100) : 0;
                        ?>
                        <tr>
                            <td><?php echo htmlspecialchars($window['subject_name']); ?></td>
                            <td><?php echo htmlspecialchars($window['class_name']); ?></td>
                            <td><?php echo htmlspecialchars($window['term_name']); ?></td>
                            <td><?php echo date('d M Y', strtotime($window['start_date'])); ?> - <?php echo date('d M Y', strtotime($window['end_date'])); ?></td>
                            <td>
                                <?php if ($window['status'] == 'open'): ?>
                                    <span class="badge bg-success">Open</span>
                                <?php else: ?>
                                    <span class="badge bg-warning">Pending</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="progress" style="height: 20px;">
                                    <div class="progress-bar" role="progressbar" style="width: <?php echo $progress; ?>%;" aria-valuenow="<?php echo $progress; ?>" aria-valuemin="0" aria-valuemax="100">
                                        <?php echo $window['submissions_count']; ?>/<?php echo $window['total_students']; ?>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <a href="exam_officer/grade_submission?window_id=<?php echo $window['id']; ?>" class="btn btn-sm btn-primary">Monitor</a>
                            </td>
                        </tr>
                        <?php 
                            endforeach;
                        else:
                        ?>
                        <tr>
                            <td colspan="7" class="text-center">No active grade submission windows</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

</main>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>
<script src="loader/waitMe.js"></script>
<script src="js/forms.js"></script>
<script src="js/sweetalert2@11.js"></script>

<script>
// Auto-refresh dashboard every 60 seconds (optional)
$(document).ready(function() {
    // Refresh metrics every 60 seconds
    setInterval(function() {
        location.reload();
    }, 60000);
});
</script>

</body>
</html>