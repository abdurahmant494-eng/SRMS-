<?php
chdir('../');
session_start();
require_once('db/config.php');
require_once('const/school.php');
require_once('const/check_session.php');

if ($res != '1' || $level != '4') {
    header('location:../');
    exit;
}

$assignments = [];
$teachers = [];
$schedules = [];

function formatSlotLabel($slotKey) {
    if (empty($slotKey)) {
        return '';
    }
    $parts = explode('_', $slotKey, 2);
    if (count($parts) !== 2) {
        return ucfirst(str_replace('_', ' ', $slotKey));
    }
    $day = ucfirst($parts[0]);
    $time = preg_replace('/(\d{2})(\d{2})$/', '$1:$2', $parts[1]);
    return trim($day . ' ' . $time);
}

try {
    $conn = new PDO('mysql:host='.DBHost.';dbname='.DBName.';charset='.DBCharset.';collation='.DBCollation.';prefix='.DBPrefix.'', DBUser, DBPass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $has_invigilators = (bool)$conn->query("SHOW TABLES LIKE 'tbl_invigilators'")->fetchColumn();
    $isDraftSchedule = (bool)$conn->query("SHOW COLUMNS FROM tbl_exam_schedules LIKE 'slot_key'")->fetchColumn();

    if ($has_invigilators) {
        if ($isDraftSchedule) {
            $stmt = $conn->prepare("
                SELECT i.id, i.status, i.assignment_date, i.duty_type,
                       es.id AS schedule_id,
                       es.term,
                       es.slot_key,
                       subj.name AS subject_name,
                       t.name AS term_name,
                       st.fname, st.lname
                FROM tbl_invigilators i
                INNER JOIN tbl_exam_schedules es ON es.id = i.exam_schedule_id
                LEFT JOIN tbl_subjects subj ON subj.id = es.subject
                LEFT JOIN tbl_terms t ON t.id = es.term
                INNER JOIN tbl_staff st ON st.id = i.teacher_id
                WHERE i.assigned_by = ?
                ORDER BY es.term ASC, es.slot_key ASC
            ");
        } else {
            $stmt = $conn->prepare("
                SELECT i.id, i.status, i.assignment_date, i.duty_type,
                       es.id AS schedule_id,
                       es.exam_date, es.start_time, es.end_time, es.venue,
                       s.name AS subject_name, c.name AS class_name,
                       st.fname, st.lname
                FROM tbl_invigilators i
                INNER JOIN tbl_exam_schedules es ON es.id = i.exam_schedule_id
                LEFT JOIN tbl_subjects s ON s.id = es.subject_id
                LEFT JOIN tbl_classes c ON c.id = es.class_id
                INNER JOIN tbl_staff st ON st.id = i.teacher_id
                WHERE i.assigned_by = ?
                ORDER BY es.exam_date ASC, es.start_time ASC
            ");
        }
        $stmt->execute([$account_id]);
        $assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    $teachers = $conn->query("SELECT id, fname, lname FROM tbl_staff WHERE level = '2' AND status = '1' ORDER BY fname, lname ASC")->fetchAll(PDO::FETCH_ASSOC);

    if ($isDraftSchedule) {
        $schedules = $conn->query("SELECT es.id, es.term, es.slot_key, subj.name AS subject_name, t.name AS term_name
            FROM tbl_exam_schedules es
            LEFT JOIN tbl_subjects subj ON subj.id = es.subject
            LEFT JOIN tbl_terms t ON t.id = es.term
            ORDER BY es.term ASC, es.slot_key ASC
            LIMIT 50")->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $schedules = $conn->query("SELECT es.id, es.exam_name, es.exam_date, es.start_time, es.end_time, es.venue,
                s.name AS subject_name, c.name AS class_name
            FROM tbl_exam_schedules es
            LEFT JOIN tbl_subjects s ON s.id = es.subject_id
            LEFT JOIN tbl_classes c ON c.id = es.class_id
            WHERE es.exam_date >= CURDATE()
            ORDER BY es.exam_date ASC, es.start_time ASC
            LIMIT 50")->fetchAll(PDO::FETCH_ASSOC);

        if (count($schedules) === 0) {
            $schedules = $conn->query("SELECT es.id, es.exam_name, es.exam_date, es.start_time, es.end_time, es.venue,
                    s.name AS subject_name, c.name AS class_name
                FROM tbl_exam_schedules es
                LEFT JOIN tbl_subjects s ON s.id = es.subject_id
                LEFT JOIN tbl_classes c ON c.id = es.class_id
                ORDER BY es.exam_date ASC, es.start_time ASC
                LIMIT 50")->fetchAll(PDO::FETCH_ASSOC);
        }
    }
} catch (PDOException $e) {
    $assignments = [];
    $teachers = [];
    $schedules = [];
}

$role_title = 'Exam Officer';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Borana University - Invigilation Duty</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<base href="../">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link rel="icon" href="images/icon.ico">
<link rel="stylesheet" type="text/css" href="cdn.jsdelivr.net/npm/bootstrap-icons%401.10.5/font/bootstrap-icons.css">
<link type="text/css" rel="stylesheet" href="loader/waitMe.css">
</head>
<body class="app sidebar-mini">
<header class="app-header"><a class="app-header__logo" href="javascript:void(0);">
<img src="images/logo/<?php echo WBLogo; ?>" alt="<?php echo WBName; ?> logo">
<span><?php echo WBName; ?></span>
</a>
<a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
<ul class="app-nav"><li class="dropdown"><a class="app-nav__item" href="#" data-bs-toggle="dropdown" aria-label="Open Profile Menu"><i class="bi bi-person fs-4"></i></a>
<ul class="dropdown-menu settings-menu dropdown-menu-right">
<li><a class="dropdown-item" href="exam_officer/profile"><i class="bi bi-person me-2 fs-5"></i> My Profile</a></li>
<li><a class="dropdown-item" href="exam_officer/settings"><i class="bi bi-gear me-2 fs-5"></i> Settings</a></li>
<li><a class="dropdown-item" href="logout"><i class="bi bi-box-arrow-right me-2 fs-5"></i> Logout</a></li>
</ul></li></ul>
</header>
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
<div class="app-sidebar__user">
<div>
<p class="app-sidebar__user-name"><?php echo $fname.' '.$lname; ?></p>
<p class="app-sidebar__user-designation"><?php echo $role_title; ?></p>
</div>
</div>
<ul class="app-menu">
<li><a class="app-menu__item" href="exam_officer"><i class="app-menu__icon feather icon-monitor"></i><span class="app-menu__label">Dashboard</span></a></li>
<li><a class="app-menu__item" href="exam_officer/exam_scheduler"><i class="app-menu__icon feather icon-calendar"></i><span class="app-menu__label">Exam Scheduler</span></a></li>
<li><a class="app-menu__item" href="exam_officer/grade_submission"><i class="app-menu__icon feather icon-upload"></i><span class="app-menu__label">Grade Submission</span></a></li>
<li><a class="app-menu__item" href="exam_officer/result_processing"><i class="app-menu__icon feather icon-bar-chart-2"></i><span class="app-menu__label">Result Processing</span></a></li>
<li><a class="app-menu__item active" href="exam_officer/invigilation"><i class="app-menu__icon feather icon-users"></i><span class="app-menu__label">Invigilation Duty</span></a></li>
<li class="treeview"><a class="app-menu__item" href="javascript:void(0);" data-toggle="treeview"><i class="app-menu__icon feather icon-file-text"></i><span class="app-menu__label">Reports</span><i class="treeview-indicator bi bi-chevron-right"></i></a>
<ul class="treeview-menu">
<li><a class="treeview-item" href="exam_officer/reports/result_slips">Result Slips</a></li>
<li><a class="treeview-item" href="exam_officer/reports/transcripts">Transcripts</a></li>
<li><a class="treeview-item" href="exam_officer/reports/attendance">Exam Attendance</a></li>
</ul></li>
<li><a class="app-menu__item" href="exam_officer/analytics"><i class="app-menu__icon feather icon-pie-chart"></i><span class="app-menu__label">Analytics</span></a></li>
</ul>
</aside>
<main class="app-content">
<div class="app-title">
<div>
<p class="dashboard-eyebrow">Borana University Exam Operations</p>
<h1>Invigilation Duty</h1>
<p>Review all exam invigilation assignments created under your supervision.</p>
</div>
</div>
<div class="row mb-4">
    <div class="col-md-12">
        <div class="tile">
            <h3 class="tile-title"><i class="bi bi-person-plus me-2"></i>Assign Invigilator</h3>
            <form class="row g-3" action="exam_officer/core/create_invigilation" method="POST" autocomplete="off">
                <div class="col-md-4">
                    <label class="form-label">Exam Schedule</label>
                    <select class="form-control" name="exam_schedule_id" required>
                        <option value="">Select Exam Session</option>
                        <?php if (count($schedules) > 0): ?>
                            <?php foreach ($schedules as $schedule): ?>
                                <?php
                                    if (!empty($schedule['exam_name'])) {
                                        $scheduleLabel = $schedule['exam_name'] . ' • ' . $schedule['subject_name'] . ' • ' . $schedule['class_name'] . ' • ' . date('d M Y', strtotime($schedule['exam_date'])) . ' • ' . substr($schedule['start_time'], 0, 5) . '-' . substr($schedule['end_time'], 0, 5) . ' • ' . $schedule['venue'];
                                    } else {
                                        $slotLabel = formatSlotLabel($schedule['slot_key'] ?? '');
                                        $scheduleLabel = trim(($schedule['term_name'] ?? 'Term') . ' • ' . ($schedule['subject_name'] ?? 'Subject') . ' • ' . $slotLabel);
                                    }
                                ?>
                                <option value="<?php echo (int)$schedule['id']; ?>"><?php echo htmlspecialchars($scheduleLabel); ?></option>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <option value="" disabled>No exam sessions available</option>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Teacher</label>
                    <select class="form-control" name="teacher_id" required>
                        <option value="">Select Teacher</option>
                        <?php if (count($teachers) > 0): ?>
                            <?php foreach ($teachers as $teacher): ?>
                                <option value="<?php echo (int)$teacher['id']; ?>"><?php echo htmlspecialchars($teacher['fname'] . ' ' . $teacher['lname']); ?></option>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <option value="" disabled>No active teachers found</option>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Duty Type</label>
                    <select class="form-control" name="duty_type" required>
                        <option value="assistant">Assistant</option>
                        <option value="chief">Chief</option>
                        <option value="supervisor">Supervisor</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Status</label>
                    <select class="form-control" name="status" required>
                        <option value="assigned">Assigned</option>
                        <option value="confirmed">Confirmed</option>
                        <option value="completed">Completed</option>
                    </select>
                </div>
                <div class="col-md-4 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">Create Assignment</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="row">
<div class="col-md-12"><div class="tile"><h3 class="tile-title"><i class="bi bi-people me-2"></i>Assignments</h3><div class="table-responsive"><table class="table table-hover"><thead><tr><th>Teacher</th><th>Subject</th><th>Class</th><th>Date</th><th>Time</th><th>Venue</th><th>Duty</th><th>Status</th></tr></thead><tbody>
                        <?php if (count($assignments) > 0): foreach ($assignments as $assignment): ?>
                        <tr>
                            <td><?php echo htmlspecialchars(($assignment['fname'] ?? '') . ' ' . ($assignment['lname'] ?? '')); ?></td>
                            <td><?php echo htmlspecialchars($assignment['subject_name'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars(isset($assignment['class_name']) && $assignment['class_name'] !== '' ? $assignment['class_name'] : 'N/A'); ?></td>
                            <td><?php echo !empty($assignment['exam_date']) ? date('d M Y', strtotime($assignment['exam_date'])) : htmlspecialchars(formatSlotLabel($assignment['slot_key'] ?? '')); ?></td>
                            <td><?php echo !empty($assignment['start_time']) ? substr($assignment['start_time'],0,5) . ' - ' . substr($assignment['end_time'] ?? '',0,5) : 'TBD'; ?></td>
                            <td><?php echo htmlspecialchars(isset($assignment['venue']) && $assignment['venue'] !== '' ? $assignment['venue'] : 'TBD'); ?></td>
                            <td><?php echo ucfirst($assignment['duty_type'] ?? 'assigned'); ?></td>
                            <td><span class="badge bg-<?php echo ($assignment['status'] ?? 'assigned') == 'assigned' ? 'warning' : 'success'; ?>"><?php echo ucfirst($assignment['status'] ?? 'assigned'); ?></span></td>
                        </tr>
                        <?php endforeach; else: ?>
                        <tr><td colspan="8" class="text-center">No invigilation assignments found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</main>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>
<script src="loader/waitMe.js"></script>
<script src="js/forms.js"></script>
<script src="js/sweetalert2@11.js"></script>
</body>
</html>
