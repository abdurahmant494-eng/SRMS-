<?php
chdir('../../');
session_start();
require_once('db/config.php');
require_once('const/school.php');
require_once('const/check_session.php');

if ($res != '1' || $level != '4') {
    header('location:../');
    exit;
}

$exams = 0;
$invigilations = 0;
$grade_windows = 0;
$results = 0;
$published = 0;

try {
    $conn = new PDO('mysql:host='.DBHost.';dbname='.DBName.';charset='.DBCharset.';collation='.DBCollation.';prefix='.DBPrefix.'', DBUser, DBPass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $exams = (int)$conn->query("SELECT COUNT(*) FROM tbl_exam_schedules")->fetchColumn();
    $results = (int)$conn->query("SELECT COUNT(*) FROM tbl_exam_results")->fetchColumn();

    try {
        $published = (int)$conn->query("SELECT COUNT(*) FROM tbl_exam_releases WHERE released = 1")->fetchColumn();
    } catch (PDOException $e) {
        $published = 0;
    }
} catch (PDOException $e) {
    $exams = 0;
    $results = 0;
    $published = 0;
}

$role_title = 'Exam Officer';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Borana University - Performance Analysis</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<base href="../../">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link rel="icon" href="images/icon.ico">
<link rel="stylesheet" type="text/css" href="cdn.jsdelivr.net/npm/bootstrap-icons%401.10.5/font/bootstrap-icons.css">
<link type="text/css" rel="stylesheet" href="loader/waitMe.css">
</head>
<body class="app sidebar-mini">
<header class="app-header"><a class="app-header__logo" href="javascript:void(0);">
<img src="images/logo/<?php echo WBLogo; ?>" alt="<?php echo WBName; ?> logo">
<span><?php echo WBName; ?></span>
</a>
<a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
<ul class="app-nav"><li class="dropdown"><a class="app-nav__item" href="#" data-bs-toggle="dropdown" aria-label="Open Profile Menu"><i class="bi bi-person fs-4"></i></a>
<ul class="dropdown-menu settings-menu dropdown-menu-right">
<li><a class="dropdown-item" href="exam_officer/profile"><i class="bi bi-person me-2 fs-5"></i> My Profile</a></li>
<li><a class="dropdown-item" href="exam_officer/settings"><i class="bi bi-gear me-2 fs-5"></i> Settings</a></li>
<li><a class="dropdown-item" href="logout"><i class="bi bi-box-arrow-right me-2 fs-5"></i> Logout</a></li>
</ul></li></ul>
</header>
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
<div class="app-sidebar__user">
<div>
<p class="app-sidebar__user-name"><?php echo $fname.' '.$lname; ?></p>
<p class="app-sidebar__user-designation"><?php echo $role_title; ?></p>
</div>
</div>
<ul class="app-menu">
<li><a class="app-menu__item" href="exam_officer"><i class="app-menu__icon feather icon-monitor"></i><span class="app-menu__label">Dashboard</span></a></li>
<li><a class="app-menu__item" href="exam_officer/exam_scheduler"><i class="app-menu__icon feather icon-calendar"></i><span class="app-menu__label">Exam Scheduler</span></a></li>
<li><a class="app-menu__item" href="exam_officer/exam_list"><i class="app-menu__icon feather icon-list"></i><span class="app-menu__label">Exam List</span></a></li>
<li><a class="app-menu__item" href="exam_officer/grade_submission"><i class="app-menu__icon feather icon-upload"></i><span class="app-menu__label">Grade Submission</span></a></li>
<li><a class="app-menu__item" href="exam_officer/result_processing"><i class="app-menu__icon feather icon-bar-chart-2"></i><span class="app-menu__label">Result Processing</span></a></li>
<li><a class="app-menu__item" href="exam_officer/invigilation"><i class="app-menu__icon feather icon-users"></i><span class="app-menu__label">Invigilation Duty</span></a></li>
<li class="treeview"><a class="app-menu__item" href="javascript:void(0);" data-toggle="treeview"><i class="app-menu__icon feather icon-file-text"></i><span class="app-menu__label">Reports</span><i class="treeview-indicator bi bi-chevron-right"></i></a>
<ul class="treeview-menu">
<li><a class="treeview-item" href="exam_officer/reports/result_slips">Result Slips</a></li>
<li><a class="treeview-item" href="exam_officer/reports/transcripts">Transcripts</a></li>
<li><a class="treeview-item" href="exam_officer/reports/attendance">Exam Attendance</a></li>
<li><a class="treeview-item active" href="exam_officer/reports/analysis">Performance Analysis</a></li>
</ul></li>
<li><a class="app-menu__item" href="exam_officer/analytics"><i class="app-menu__icon feather icon-pie-chart"></i><span class="app-menu__label">Analytics</span></a></li>
</ul>
</aside>
<main class="app-content">
<div class="app-title">
<div>
<p class="dashboard-eyebrow">Borana University Exam Operations</p>
<h1>Performance Analysis</h1>
<p>Track key exam operations at a glance.</p>
</div>
</div>
<div class="row">
<div class="col-md-3"><div class="tile"><h5>Scheduled Exams</h5><p class="fs-3 mb-0"><?php echo number_format((int)$exams); ?></p></div></div>
<div class="col-md-3"><div class="tile"><h5>Invigilation Assignments</h5><p class="fs-3 mb-0"><?php echo number_format((int)$invigilations); ?></p></div></div>
<div class="col-md-3"><div class="tile"><h5>Grade Windows</h5><p class="fs-3 mb-0"><?php echo number_format((int)$grade_windows); ?></p></div></div>
<div class="col-md-3"><div class="tile"><h5>Result Records</h5><p class="fs-3 mb-0"><?php echo number_format((int)$results); ?></p></div></div>
</div>
<div class="row mt-4">
<div class="col-md-12"><div class="tile"><h3 class="tile-title"><i class="bi bi-bar-chart me-2"></i>Publication Summary</h3><p class="mb-0">Published reports: <?php echo number_format((int)$published); ?></p></div></div>
</div>
</main>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>
<script src="loader/waitMe.js"></script>
<script src="js/forms.js"></script>
<script src="js/sweetalert2@11.js"></script>
</body>
</html>
