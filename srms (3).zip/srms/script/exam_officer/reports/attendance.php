<?php
chdir('../../');
session_start();
require_once('db/config.php');
require_once('const/school.php');
require_once('const/check_session.php');

if ($res != '1' || $level != '4') {
    header('location:../../');
    exit;
}

$schedule_id = isset($_GET['schedule_id']) ? (int)$_GET['schedule_id'] : 0;
$schedules = [];
$selected_schedule = null;
$students = [];

try {
    $conn = new PDO('mysql:host='.DBHost.';dbname='.DBName.';charset='.DBCharset.';collation='.DBCollation.';prefix='.DBPrefix.'', DBUser, DBPass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $conn->exec("CREATE TABLE IF NOT EXISTS tbl_exam_attendance (
        id INT NOT NULL AUTO_INCREMENT,
        exam_schedule_id INT NOT NULL,
        student_id INT NOT NULL,
        status ENUM('present','absent') NOT NULL DEFAULT 'present',
        recorded_by INT NOT NULL,
        recorded_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY uniq_exam_student (exam_schedule_id, student_id),
        KEY idx_exam_schedule (exam_schedule_id),
        KEY idx_student (student_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

    $schedule_stmt = $conn->prepare("SELECT es.id, es.exam_name, es.exam_date, es.start_time, es.end_time, es.venue, t.name AS term_name, c.name AS class_name, s.name AS subject_name,
            (SELECT COUNT(*) FROM tbl_students st WHERE st.class = es.class_id) AS expected_students,
            (SELECT COUNT(*) FROM tbl_exam_attendance att WHERE att.exam_schedule_id = es.id AND att.status = 'present') AS present_count,
            (SELECT COUNT(*) FROM tbl_exam_attendance att WHERE att.exam_schedule_id = es.id AND att.status = 'absent') AS absent_count
        FROM tbl_exam_schedules es
        LEFT JOIN tbl_terms t ON t.id = es.term_id
        LEFT JOIN tbl_classes c ON c.id = es.class_id
        LEFT JOIN tbl_subjects s ON s.id = es.subject_id
        ORDER BY es.exam_date DESC, es.start_time DESC");
    $schedule_stmt->execute();
    $schedules = $schedule_stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($schedule_id > 0) {
        $schedule_detail = $conn->prepare("SELECT es.id, es.exam_name, es.exam_date, es.start_time, es.end_time, es.venue, t.name AS term_name, c.name AS class_name, s.name AS subject_name, es.class_id
            FROM tbl_exam_schedules es
            LEFT JOIN tbl_terms t ON t.id = es.term_id
            LEFT JOIN tbl_classes c ON c.id = es.class_id
            LEFT JOIN tbl_subjects s ON s.id = es.subject_id
            WHERE es.id = ?");
        $schedule_detail->execute([$schedule_id]);
        $selected_schedule = $schedule_detail->fetch(PDO::FETCH_ASSOC);

        if ($selected_schedule) {
            $student_stmt = $conn->prepare("SELECT st.id, st.fname, st.mname, st.lname,
                    COALESCE(att.status, 'absent') AS status
                FROM tbl_students st
                LEFT JOIN tbl_exam_attendance att ON att.student_id = st.id AND att.exam_schedule_id = ?
                WHERE st.class = ?
                ORDER BY st.lname, st.fname");
            $student_stmt->execute([$schedule_id, $selected_schedule['class_id']]);
            $students = $student_stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }
} catch (PDOException $e) {
    $schedules = [];
    $selected_schedule = null;
    $students = [];
}

$role_title = 'Exam Officer';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Borana University - Exam Attendance</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<base href="../../">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link rel="icon" href="images/icon.ico">
<link rel="stylesheet" type="text/css" href="cdn.jsdelivr.net/npm/bootstrap-icons%401.10.5/font/bootstrap-icons.css">
<link type="text/css" rel="stylesheet" href="loader/waitMe.css">
<style>
    .attendance-summary {
        margin-bottom: 20px;
    }
    .attendance-card {
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        padding: 18px;
        background: #ffffff;
        box-shadow: 0 6px 20px rgba(15, 23, 42, 0.05);
        min-height: 120px;
    }
    .attendance-card strong {
        display: block;
        font-size: 2rem;
        color: #111827;
    }
    .attendance-card span {
        color: #6b7280;
        font-size: 0.95rem;
    }
</style>
</head>
<body class="app sidebar-mini">
<header class="app-header"><a class="app-header__logo" href="javascript:void(0);">
<img src="images/logo/<?php echo WBLogo; ?>" alt="<?php echo WBName; ?> logo">
<span><?php echo WBName; ?></span>
</a>
<a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
<ul class="app-nav"><li class="dropdown"><a class="app-nav__item" href="#" data-bs-toggle="dropdown" aria-label="Open Profile Menu"><i class="bi bi-person fs-4"></i></a>
<ul class="dropdown-menu settings-menu dropdown-menu-right">
<li><a class="dropdown-item" href="exam_officer/profile"><i class="bi bi-person me-2 fs-5"></i> My Profile</a></li>
<li><a class="dropdown-item" href="exam_officer/settings"><i class="bi bi-gear me-2 fs-5"></i> Settings</a></li>
<li><a class="dropdown-item" href="logout"><i class="bi bi-box-arrow-right me-2 fs-5"></i> Logout</a></li>
</ul></li></ul>
</header>
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
<div class="app-sidebar__user">
<div>
<p class="app-sidebar__user-name"><?php echo $fname.' '.$lname; ?></p>
<p class="app-sidebar__user-designation"><?php echo $role_title; ?></p>
</div>
</div>
<ul class="app-menu">
<li><a class="app-menu__item" href="exam_officer"><i class="app-menu__icon feather icon-monitor"></i><span class="app-menu__label">Dashboard</span></a></li>
<li><a class="app-menu__item" href="exam_officer/exam_scheduler"><i class="app-menu__icon feather icon-calendar"></i><span class="app-menu__label">Exam Scheduler</span></a></li>
<li><a class="app-menu__item" href="exam_officer/grade_submission"><i class="app-menu__icon feather icon-upload"></i><span class="app-menu__label">Grade Submission</span></a></li>
<li><a class="app-menu__item" href="exam_officer/result_processing"><i class="app-menu__icon feather icon-bar-chart-2"></i><span class="app-menu__label">Result Processing</span></a></li>
<li><a class="app-menu__item" href="exam_officer/invigilation"><i class="app-menu__icon feather icon-users"></i><span class="app-menu__label">Invigilation Duty</span></a></li>
<li class="treeview is-expanded"><a class="app-menu__item active" href="javascript:void(0);" data-toggle="treeview"><i class="app-menu__icon feather icon-file-text"></i><span class="app-menu__label">Reports</span><i class="treeview-indicator bi bi-chevron-right"></i></a>
<ul class="treeview-menu">
<li><a class="treeview-item" href="exam_officer/reports/result_slips">Result Slips</a></li>
<li><a class="treeview-item" href="exam_officer/reports/transcripts">Transcripts</a></li>
<li><a class="treeview-item active" href="exam_officer/reports/attendance">Exam Attendance</a></li>
</ul></li>
<li><a class="app-menu__item" href="exam_officer/analytics"><i class="app-menu__icon feather icon-pie-chart"></i><span class="app-menu__label">Analytics</span></a></li>
</ul>
</aside>
<main class="app-content">
<div class="app-title">
<div>
<h1>Exam Attendance</h1>
<p>Review attendance trends for scheduled exam sessions and record student attendance.</p>
</div>
</div>
<div class="attendance-summary row">
    <div class="col-md-4">
        <div class="attendance-card">
            <strong><?php echo number_format(count($schedules)); ?></strong>
            <span>Exam Sessions</span>
        </div>
    </div>
    <div class="col-md-4">
        <div class="attendance-card">
            <strong><?php echo number_format(array_sum(array_column($schedules, 'expected_students'))); ?></strong>
            <span>Expected Candidates</span>
        </div>
    </div>
    <div class="col-md-4">
        <div class="attendance-card">
            <strong><?php echo number_format(array_sum(array_column($schedules, 'present_count'))); ?></strong>
            <span>Present Students Recorded</span>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="tile">
            <h3 class="tile-title"><i class="bi bi-calendar-check me-2"></i>Exam Sessions</h3>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Session</th>
                            <th>Class</th>
                            <th>Subject</th>
                            <th>Date</th>
                            <th>Venue</th>
                            <th>Expected</th>
                            <th>Present</th>
                            <th>Absent</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($schedules) > 0): foreach ($schedules as $session): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($session['exam_name'] . ' (' . $session['term_name'] . ')'); ?></td>
                            <td><?php echo htmlspecialchars($session['class_name']); ?></td>
                            <td><?php echo htmlspecialchars($session['subject_name']); ?></td>
                            <td><?php echo date('d M Y', strtotime($session['exam_date'])) . ' ' . substr($session['start_time'], 0, 5) . ' - ' . substr($session['end_time'], 0, 5); ?></td>
                            <td><?php echo htmlspecialchars($session['venue']); ?></td>
                            <td><?php echo number_format($session['expected_students']); ?></td>
                            <td><?php echo number_format($session['present_count']); ?></td>
                            <td><?php echo number_format($session['absent_count']); ?></td>
                            <td><a href="exam_officer/reports/attendance?schedule_id=<?php echo (int)$session['id']; ?>" class="btn btn-sm btn-primary">Record/View</a></td>
                        </tr>
                        <?php endforeach; else: ?>
                        <tr><td colspan="9" class="text-center">No exam sessions found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php if ($selected_schedule): ?>
<div class="row mt-4">
    <div class="col-md-12">
        <div class="tile">
            <h3 class="tile-title"><i class="bi bi-pencil-square me-2"></i>Record Attendance</h3>
            <p><strong>Session:</strong> <?php echo htmlspecialchars($selected_schedule['exam_name']); ?>
            | <strong>Class:</strong> <?php echo htmlspecialchars($selected_schedule['class_name']); ?>
            | <strong>Subject:</strong> <?php echo htmlspecialchars($selected_schedule['subject_name']); ?>
            | <strong>Date:</strong> <?php echo date('d M Y', strtotime($selected_schedule['exam_date'])); ?></p>
            <form action="exam_officer/core/record_attendance" method="POST">
                <input type="hidden" name="exam_schedule_id" value="<?php echo (int)$selected_schedule['id']; ?>">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Student</th>
                                <th>Attendance</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($students) > 0): foreach ($students as $index => $student): ?>
                            <tr>
                                <td><?php echo $index + 1; ?></td>
                                <td><?php echo htmlspecialchars(trim($student['fname'] . ' ' . $student['mname'] . ' ' . $student['lname'])); ?></td>
                                <td>
                                    <select class="form-control" name="attendance[<?php echo (int)$student['id']; ?>]">
                                        <option value="present"<?php echo $student['status'] === 'present' ? ' selected' : ''; ?>>Present</option>
                                        <option value="absent"<?php echo $student['status'] === 'absent' ? ' selected' : ''; ?>>Absent</option>
                                    </select>
                                </td>
                            </tr>
                            <?php endforeach; else: ?>
                            <tr><td colspan="3" class="text-center">No students found for this class.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <button type="submit" class="btn btn-success">Save Attendance</button>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>
</main>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>
<script src="loader/waitMe.js"></script>
<script src="js/forms.js"></script>
<script src="js/sweetalert2@11.js"></script>
<?php if (file_exists('const/check-reply.php')) { require_once('const/check-reply.php'); } ?>
</body>
</html>
