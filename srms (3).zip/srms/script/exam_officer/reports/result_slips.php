<?php
chdir('../../');
session_start();
require_once('db/config.php');
require_once('const/school.php');
require_once('const/check_session.php');

if ($res != '1' || $level != '4') {
    header('location:../../');
    exit;
}

$class_id = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
$term_id = isset($_GET['term_id']) ? (int)$_GET['term_id'] : 0;
$student_id = isset($_GET['student_id']) ? trim($_GET['student_id']) : '';
$published = 0;
$classes = [];
$terms = [];
$students = [];
$summary_rows = [];
$student_results = [];
$selected_student = null;
$grade_system = [];

function gradeForScore($score, $grade_system)
{
    foreach ($grade_system as $grade) {
        if ($score >= (float)$grade['min'] && $score <= (float)$grade['max']) {
            return [
                'name' => $grade['name'],
                'remark' => $grade['remark'],
            ];
        }
    }
    return ['name' => 'N/A', 'remark' => 'N/A'];
}

try {
    $conn = new PDO('mysql:host='.DBHost.';dbname='.DBName.';charset='.DBCharset.';collation='.DBCollation.';prefix='.DBPrefix.'', DBUser, DBPass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $showReleases = (bool)$conn->query("SHOW TABLES LIKE 'tbl_exam_releases'")->fetchColumn();
    if ($showReleases) {
        $published = (int)$conn->query("SELECT COUNT(*) FROM tbl_exam_releases WHERE released = 1")->fetchColumn();
    }

    $gradeStmt = $conn->prepare("SELECT * FROM tbl_grade_system ORDER BY min DESC");
    $gradeStmt->execute();
    $grade_system = $gradeStmt->fetchAll(PDO::FETCH_ASSOC);

    $classStmt = $conn->prepare("SELECT id, name FROM tbl_classes ORDER BY name");
    $classStmt->execute();
    $classes = $classStmt->fetchAll(PDO::FETCH_ASSOC);

    if ($showReleases) {
        $termStmt = $conn->prepare("SELECT DISTINCT t.id, t.name FROM tbl_terms t INNER JOIN tbl_exam_results er ON er.term = t.id INNER JOIN tbl_exam_releases r ON r.term = t.id WHERE r.released = 1 ORDER BY t.id DESC");
    } else {
        $termStmt = $conn->prepare("SELECT DISTINCT t.id, t.name FROM tbl_terms t INNER JOIN tbl_exam_results er ON er.term = t.id ORDER BY t.id DESC");
    }
    $termStmt->execute();
    $terms = $termStmt->fetchAll(PDO::FETCH_ASSOC);
    if (empty($terms)) {
        $fallbackTermStmt = $conn->prepare("SELECT id, name FROM tbl_terms ORDER BY id DESC");
        $fallbackTermStmt->execute();
        $terms = $fallbackTermStmt->fetchAll(PDO::FETCH_ASSOC);
    }

    if ($class_id > 0) {
        $studentStmt = $conn->prepare("SELECT id, fname, mname, lname FROM tbl_students WHERE class = ? ORDER BY lname, fname");
        $studentStmt->execute([$class_id]);
        $students = $studentStmt->fetchAll(PDO::FETCH_ASSOC);
    }

    if ($class_id > 0 && $term_id > 0) {
        $summaryStmt = $conn->prepare("SELECT s.id AS student_id, s.fname, s.mname, s.lname, COUNT(er.id) AS subjects_count, ROUND(AVG(er.score), 2) AS average_score FROM tbl_exam_results er INNER JOIN tbl_students s ON er.student = s.id WHERE er.class = ? AND er.term = ? GROUP BY s.id ORDER BY s.lname, s.fname");
        $summaryStmt->execute([$class_id, $term_id]);
        $summary_rows = $summaryStmt->fetchAll(PDO::FETCH_ASSOC);

        if ($student_id !== '') {
            $studentDetailStmt = $conn->prepare("SELECT er.*, sub.name AS subject_name, COALESCE(er.grade, g.name) AS grade_name, COALESCE(g.remark, 'N/A') AS grade_remark, t.name AS term_name, c.name AS class_name, s.fname, s.mname, s.lname, s.id AS student_id FROM tbl_exam_results er INNER JOIN tbl_students s ON er.student = s.id INNER JOIN tbl_classes c ON er.class = c.id INNER JOIN tbl_terms t ON er.term = t.id LEFT JOIN tbl_subject_combinations sc ON er.subject_combination = sc.id LEFT JOIN tbl_subjects sub ON sc.subject = sub.id LEFT JOIN tbl_grade_system g ON er.score BETWEEN g.min AND g.max WHERE er.class = ? AND er.term = ? AND er.student = ? ORDER BY sub.name");
            $studentDetailStmt->execute([$class_id, $term_id, $student_id]);
            $student_results = $studentDetailStmt->fetchAll(PDO::FETCH_ASSOC);
            if (count($student_results) > 0) {
                $selected_student = $student_results[0];
            }
        }
    }
} catch (PDOException $e) {
    $published = 0;
    $classes = [];
    $terms = [];
    $students = [];
    $summary_rows = [];
    $student_results = [];
}

$role_title = 'Exam Officer';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Borana University - Result Slips</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<base href="../../">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link rel="icon" href="images/icon.ico">
<link rel="stylesheet" type="text/css" href="cdn.jsdelivr.net/npm/bootstrap-icons%401.10.5/font/bootstrap-icons.css">
<link type="text/css" rel="stylesheet" href="loader/waitMe.css">
</head>
<body class="app sidebar-mini">
<header class="app-header"><a class="app-header__logo" href="javascript:void(0);">
<img src="images/logo/<?php echo WBLogo; ?>" alt="<?php echo WBName; ?> logo">
<span><?php echo WBName; ?></span>
</a>
<a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
<ul class="app-nav"><li class="dropdown"><a class="app-nav__item" href="#" data-bs-toggle="dropdown" aria-label="Open Profile Menu"><i class="bi bi-person fs-4"></i></a>
<ul class="dropdown-menu settings-menu dropdown-menu-right">
<li><a class="dropdown-item" href="exam_officer/profile"><i class="bi bi-person me-2 fs-5"></i> My Profile</a></li>
<li><a class="dropdown-item" href="exam_officer/settings"><i class="bi bi-gear me-2 fs-5"></i> Settings</a></li>
<li><a class="dropdown-item" href="logout"><i class="bi bi-box-arrow-right me-2 fs-5"></i> Logout</a></li>
</ul></li></ul>
</header>
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
<div class="app-sidebar__user">
<div>
<p class="app-sidebar__user-name"><?php echo $fname.' '.$lname; ?></p>
<p class="app-sidebar__user-designation"><?php echo $role_title; ?></p>
</div>
</div>
<ul class="app-menu">
<li><a class="app-menu__item" href="exam_officer"><i class="app-menu__icon feather icon-monitor"></i><span class="app-menu__label">Dashboard</span></a></li>
<li><a class="app-menu__item" href="exam_officer/exam_scheduler"><i class="app-menu__icon feather icon-calendar"></i><span class="app-menu__label">Exam Scheduler</span></a></li>
<li><a class="app-menu__item" href="exam_officer/grade_submission"><i class="app-menu__icon feather icon-upload"></i><span class="app-menu__label">Grade Submission</span></a></li>
<li><a class="app-menu__item" href="exam_officer/result_processing"><i class="app-menu__icon feather icon-bar-chart-2"></i><span class="app-menu__label">Result Processing</span></a></li>
<li><a class="app-menu__item" href="exam_officer/invigilation"><i class="app-menu__icon feather icon-users"></i><span class="app-menu__label">Invigilation Duty</span></a></li>
<li class="treeview"><a class="app-menu__item active" href="javascript:void(0);" data-toggle="treeview"><i class="app-menu__icon feather icon-file-text"></i><span class="app-menu__label">Reports</span><i class="treeview-indicator bi bi-chevron-right"></i></a>
<ul class="treeview-menu">
<li><a class="treeview-item active" href="exam_officer/reports/result_slips">Result Slips</a></li>
<li><a class="treeview-item" href="exam_officer/reports/transcripts">Transcripts</a></li>
<li><a class="treeview-item" href="exam_officer/reports/attendance">Exam Attendance</a></li>
</ul></li>
<li><a class="app-menu__item" href="exam_officer/analytics"><i class="app-menu__icon feather icon-pie-chart"></i><span class="app-menu__label">Analytics</span></a></li>
</ul>
</aside>
<main class="app-content">
<div class="app-title">
<div>
<h1>Result Slips</h1>
<p>Generate and review result slips for published exams.</p>
</div>
</div>
<div class="row">
    <div class="col-md-4"><div class="tile"><h5>Published Terms</h5><p class="fs-3 mb-0"><?php echo number_format((int)$published); ?></p></div></div>
    <div class="col-md-8"><div class="tile"><h3 class="tile-title"><i class="bi bi-funnel me-2"></i>Filter by Class and Term</h3>
        <form method="GET" action="exam_officer/reports/result_slips">
            <div class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label class="form-label">Class</label>
                    <select class="form-control" name="class_id">
                        <option value="">Select class</option>
                        <?php foreach ($classes as $classRow): ?>
                        <option value="<?php echo (int)$classRow['id']; ?>"<?php echo $class_id === (int)$classRow['id'] ? ' selected' : ''; ?>><?php echo htmlspecialchars($classRow['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Term</label>
                    <select class="form-control" name="term_id">
                        <option value="">Select term</option>
                        <?php foreach ($terms as $termRow): ?>
                        <option value="<?php echo (int)$termRow['id']; ?>"<?php echo $term_id === (int)$termRow['id'] ? ' selected' : ''; ?>><?php echo htmlspecialchars($termRow['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary w-100">Load Result Slips</button>
                </div>
            </div>
        </form>
    </div></div>
</div>
<?php if ($class_id > 0 && $term_id > 0): ?>
<div class="row mt-3">
    <div class="col-md-12">
        <div class="tile">
            <h3 class="tile-title"><i class="bi bi-table me-2"></i>Result Slip Summary</h3>
            <div class="table-responsive">
                <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Subjects</th>
                            <th>Average Score</th>
                            <th>Grade</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($summary_rows) > 0): foreach ($summary_rows as $row): $grade = gradeForScore((float)$row['average_score'], $grade_system); ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['student_id']); ?></td>
                            <td><?php echo htmlspecialchars(trim($row['fname'] . ' ' . $row['mname'] . ' ' . $row['lname'])); ?></td>
                            <td><?php echo (int)$row['subjects_count']; ?></td>
                            <td><?php echo number_format((float)$row['average_score'], 2); ?>%</td>
                            <td><?php echo htmlspecialchars($grade['name']); ?></td>
                            <td>
                                <a href="exam_officer/reports/result_slips?class_id=<?php echo (int)$class_id; ?>&term_id=<?php echo (int)$term_id; ?>&student_id=<?php echo urlencode($row['student_id']); ?>" class="btn btn-sm btn-outline-secondary me-1">View Slip</a>
                                <a target="_blank" href="exam_officer/save_transcript?std=<?php echo urlencode($row['student_id']); ?>&term=<?php echo (int)$term_id; ?>&class_id=<?php echo (int)$class_id; ?>" class="btn btn-sm btn-success">Download Full Transcript PDF</a>
                            </td>
                        </tr>
                        <?php endforeach; else: ?>
                        <tr><td colspan="6" class="text-center">No published result slips available for this class and term.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php if ($selected_student && count($student_results) > 0): ?>
<div class="row mt-3">
    <div class="col-md-12">
        <div class="tile">
            <h3 class="tile-title"><i class="bi bi-file-earmark-text me-2"></i>Result Slip for <?php echo htmlspecialchars(trim($selected_student['fname'] . ' ' . $selected_student['mname'] . ' ' . $selected_student['lname'])); ?></h3>
            <p class="mb-2"><strong>Student ID:</strong> <?php echo htmlspecialchars($selected_student['student_id']); ?>
            <strong class="ms-4">Class:</strong> <?php echo htmlspecialchars($selected_student['class_name']); ?>
            <strong class="ms-4">Term:</strong> <?php echo htmlspecialchars($selected_student['term_name']); ?></p>
            <div class="mb-3">
                <a target="_blank" href="exam_officer/save_pdf?std=<?php echo urlencode($selected_student['student_id']); ?>&term=<?php echo (int)$term_id; ?>" class="btn btn-primary btn-sm me-2">Download Slip PDF</a>
                <a target="_blank" href="exam_officer/save_transcript?std=<?php echo urlencode($selected_student['student_id']); ?>&term=<?php echo (int)$term_id; ?>&class_id=<?php echo (int)$class_id; ?>" class="btn btn-success btn-sm me-2">Download Transcript PDF</a>
                <button type="button" class="btn btn-outline-secondary btn-sm" onclick="window.print()">Print Slip</button>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Subject</th>
                            <th>Score</th>
                            <th>Grade</th>
                            <th>Remark</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $count = 0; $totalScore = 0; foreach ($student_results as $result): $count++; $totalScore += (float)$result['score']; $grade = gradeForScore((float)$result['score'], $grade_system); ?>
                        <tr>
                            <td><?php echo $count; ?></td>
                            <td><?php echo htmlspecialchars($result['subject_name'] ?: 'Unknown Subject'); ?></td>
                            <td><?php echo number_format((float)$result['score'], 2); ?>%</td>
                            <td><?php echo htmlspecialchars($result['grade_name']); ?></td>
                            <td><?php echo htmlspecialchars($result['grade_remark']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php $average = $count > 0 ? round($totalScore / $count, 2) : 0; $averageGrade = gradeForScore($average, $grade_system); ?>
            <div class="row mt-3">
                <div class="col-md-4"><div class="alert alert-secondary"><strong>Total Subjects:</strong> <?php echo $count; ?></div></div>
                <div class="col-md-4"><div class="alert alert-secondary"><strong>Average Score:</strong> <?php echo number_format($average, 2); ?>%</div></div>
                <div class="col-md-4"><div class="alert alert-secondary"><strong>Overall Grade:</strong> <?php echo htmlspecialchars($averageGrade['name']); ?> - <?php echo htmlspecialchars($averageGrade['remark']); ?></div></div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
</main>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>
<script src="loader/waitMe.js"></script>
<script src="js/forms.js"></script>
<script src="js/sweetalert2@11.js"></script>
<?php if (file_exists('const/check-reply.php')) { require_once('const/check-reply.php'); } ?>
</body>
</html>
