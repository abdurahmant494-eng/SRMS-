<?php
chdir('../../');
session_start();
require_once('db/config.php');
require_once('const/school.php');
require_once('const/check_session.php');

if ($res != '1' || $level != '4') {
    header('location:../../');
    exit;
}

$class_id = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
$student_id = isset($_GET['student_id']) ? trim($_GET['student_id']) : '';
$classes = [];
$students = [];
$transcript = [];
$term_summary = [];
$student_profile = null;
$grade_system = [];

function gradeForScore($score, $grade_system)
{
    foreach ($grade_system as $grade) {
        if ($score >= (float)$grade['min'] && $score <= (float)$grade['max']) {
            return [
                'name' => $grade['name'],
                'remark' => $grade['remark'],
            ];
        }
    }
    return ['name' => 'N/A', 'remark' => 'N/A'];
}

try {
    $conn = new PDO('mysql:host='.DBHost.';dbname='.DBName.';charset='.DBCharset.';collation='.DBCollation.';prefix='.DBPrefix.'', DBUser, DBPass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $gradeStmt = $conn->prepare("SELECT * FROM tbl_grade_system ORDER BY min DESC");
    $gradeStmt->execute();
    $grade_system = $gradeStmt->fetchAll(PDO::FETCH_ASSOC);

    $classStmt = $conn->prepare("SELECT id, name FROM tbl_classes ORDER BY name");
    $classStmt->execute();
    $classes = $classStmt->fetchAll(PDO::FETCH_ASSOC);

    if ($class_id > 0) {
        $studentStmt = $conn->prepare("SELECT id, fname, mname, lname FROM tbl_students WHERE class = ? ORDER BY lname, fname");
        $studentStmt->execute([$class_id]);
        $students = $studentStmt->fetchAll(PDO::FETCH_ASSOC);
    }

    if ($student_id !== '') {
        $profileStmt = $conn->prepare("SELECT s.id AS student_id, s.fname, s.mname, s.lname, c.name AS class_name FROM tbl_students s INNER JOIN tbl_classes c ON s.class = c.id WHERE s.id = ?");
        $profileStmt->execute([$student_id]);
        $student_profile = $profileStmt->fetch(PDO::FETCH_ASSOC);

        $transcriptStmt = $conn->prepare("SELECT er.*, t.id AS term_id, t.name AS term_name, c.name AS class_name, sub.name AS subject_name, COALESCE(er.grade, g.name) AS grade_name, COALESCE(g.remark, 'N/A') AS grade_remark FROM tbl_exam_results er INNER JOIN tbl_terms t ON er.term = t.id INNER JOIN tbl_classes c ON er.class = c.id LEFT JOIN tbl_subject_combinations sc ON er.subject_combination = sc.id LEFT JOIN tbl_subjects sub ON sc.subject = sub.id LEFT JOIN tbl_grade_system g ON er.score BETWEEN g.min AND g.max WHERE er.student = ? " . ($class_id > 0 ? " AND er.class = ?" : "") . " ORDER BY t.id ASC, sub.name ASC");
        if ($class_id > 0) {
            $transcriptStmt->execute([$student_id, $class_id]);
        } else {
            $transcriptStmt->execute([$student_id]);
        }
        $transcript = $transcriptStmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($transcript as $row) {
            $term_id_group = (int)$row['term_id'];
            if (!isset($term_summary[$term_id_group])) {
                $term_summary[$term_id_group] = [
                    'term_name' => $row['term_name'],
                    'class_name' => $row['class_name'],
                    'scores' => [],
                    'total_score' => 0,
                    'subject_count' => 0,
                ];
            }
            $term_summary[$term_id_group]['scores'][] = $row;
            $term_summary[$term_id_group]['total_score'] += (float)$row['score'];
            $term_summary[$term_id_group]['subject_count']++;
        }
    }
} catch (PDOException $e) {
    $classes = [];
    $students = [];
    $transcript = [];
    $term_summary = [];
    $student_profile = null;
}

$role_title = 'Exam Officer';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Borana University - Transcripts</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<base href="../../">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link rel="icon" href="images/icon.ico">
<link rel="stylesheet" type="text/css" href="cdn.jsdelivr.net/npm/bootstrap-icons%401.10.5/font/bootstrap-icons.css">
<link type="text/css" rel="stylesheet" href="loader/waitMe.css">
</head>
<body class="app sidebar-mini">
<header class="app-header"><a class="app-header__logo" href="javascript:void(0);">
<img src="images/logo/<?php echo WBLogo; ?>" alt="<?php echo WBName; ?> logo">
<span><?php echo WBName; ?></span>
</a>
<a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
<ul class="app-nav"><li class="dropdown"><a class="app-nav__item" href="#" data-bs-toggle="dropdown" aria-label="Open Profile Menu"><i class="bi bi-person fs-4"></i></a>
<ul class="dropdown-menu settings-menu dropdown-menu-right">
<li><a class="dropdown-item" href="exam_officer/profile"><i class="bi bi-person me-2 fs-5"></i> My Profile</a></li>
<li><a class="dropdown-item" href="exam_officer/settings"><i class="bi bi-gear me-2 fs-5"></i> Settings</a></li>
<li><a class="dropdown-item" href="logout"><i class="bi bi-box-arrow-right me-2 fs-5"></i> Logout</a></li>
</ul></li></ul>
</header>
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
<div class="app-sidebar__user">
<div>
<p class="app-sidebar__user-name"><?php echo $fname.' '.$lname; ?></p>
<p class="app-sidebar__user-designation"><?php echo $role_title; ?></p>
</div>
</div>
<ul class="app-menu">
<li><a class="app-menu__item" href="exam_officer"><i class="app-menu__icon feather icon-monitor"></i><span class="app-menu__label">Dashboard</span></a></li>
<li><a class="app-menu__item" href="exam_officer/exam_scheduler"><i class="app-menu__icon feather icon-calendar"></i><span class="app-menu__label">Exam Scheduler</span></a></li>
<li><a class="app-menu__item" href="exam_officer/grade_submission"><i class="app-menu__icon feather icon-upload"></i><span class="app-menu__label">Grade Submission</span></a></li>
<li><a class="app-menu__item" href="exam_officer/result_processing"><i class="app-menu__icon feather icon-bar-chart-2"></i><span class="app-menu__label">Result Processing</span></a></li>
<li><a class="app-menu__item" href="exam_officer/invigilation"><i class="app-menu__icon feather icon-users"></i><span class="app-menu__label">Invigilation Duty</span></a></li>
<li class="treeview"><a class="app-menu__item active" href="javascript:void(0);" data-toggle="treeview"><i class="app-menu__icon feather icon-file-text"></i><span class="app-menu__label">Reports</span><i class="treeview-indicator bi bi-chevron-right"></i></a>
<ul class="treeview-menu">
<li><a class="treeview-item" href="exam_officer/reports/result_slips">Result Slips</a></li>
<li><a class="treeview-item active" href="exam_officer/reports/transcripts">Transcripts</a></li>
<li><a class="treeview-item" href="exam_officer/reports/attendance">Exam Attendance</a></li>
</ul></li>
<li><a class="app-menu__item" href="exam_officer/analytics"><i class="app-menu__icon feather icon-pie-chart"></i><span class="app-menu__label">Analytics</span></a></li>
</ul>
</aside>
<main class="app-content">
<div class="app-title">
<div>
<h1>Transcripts</h1>
<p>Review transcript-ready performance summaries for the current academic cycle.</p>
</div>
</div>
<div class="row">
    <div class="col-md-12"><div class="tile"><h3 class="tile-title"><i class="bi bi-folder2-open me-2"></i>Choose Student</h3>
        <form method="GET" action="exam_officer/reports/transcripts">
            <div class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label class="form-label">Class</label>
                    <select class="form-control" name="class_id" onchange="this.form.submit()">
                        <option value="">Select class</option>
                        <?php foreach ($classes as $classRow): ?>
                        <option value="<?php echo (int)$classRow['id']; ?>"<?php echo $class_id === (int)$classRow['id'] ? ' selected' : ''; ?>><?php echo htmlspecialchars($classRow['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Student</label>
                    <select class="form-control" name="student_id">
                        <option value="">Select student</option>
                        <?php foreach ($students as $student): ?>
                        <option value="<?php echo htmlspecialchars($student['id']); ?>"<?php echo $student_id === $student['id'] ? ' selected' : ''; ?>><?php echo htmlspecialchars(trim($student['fname'] . ' ' . $student['mname'] . ' ' . $student['lname'])); ?> (<?php echo htmlspecialchars($student['id']); ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary w-100">Load Transcript</button>
                </div>
            </div>
        </form>
    </div></div>
</div>
<?php if ($student_profile && count($term_summary) > 0): ?>
<div class="row mt-3">
    <div class="col-md-12">
        <div class="tile">
            <h3 class="tile-title"><i class="bi bi-person-badge me-2"></i>Transcript for <?php echo htmlspecialchars(trim($student_profile['fname'] . ' ' . $student_profile['mname'] . ' ' . $student_profile['lname'])); ?></h3>
            <p class="mb-2"><strong>Student ID:</strong> <?php echo htmlspecialchars($student_profile['student_id']); ?>
            <strong class="ms-4">Class:</strong> <?php echo htmlspecialchars($student_profile['class_name']); ?></p>
            <div class="mb-3">
                <button type="button" class="btn btn-primary btn-sm me-2" onclick="window.print()">Print Transcript</button>
                <a target="_blank" href="exam_officer/save_transcript?std=<?php echo urlencode($student_profile['student_id']); ?><?php echo $class_id ? '&class_id='.(int)$class_id : ''; ?>" class="btn btn-sm btn-success me-2">Download Full Transcript PDF</a>
                <span class="text-muted">Download each term report card below.</span>
            </div>
            <?php foreach ($term_summary as $termId => $termData): $termAverage = $termData['subject_count'] ? round($termData['total_score'] / $termData['subject_count'], 2) : 0; $termGrade = gradeForScore($termAverage, $grade_system); ?>
            <div class="mb-4">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h4 class="mb-0"><?php echo htmlspecialchars($termData['term_name']); ?></h4>
                    <a target="_blank" href="exam_officer/save_transcript?std=<?php echo urlencode($student_profile['student_id']); ?>&term=<?php echo (int)$termId; ?><?php echo $class_id ? '&class_id='.(int)$class_id : ''; ?>" class="btn btn-sm btn-primary">Download Term PDF</a>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped mb-2">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Subject</th>
                                <th>Score</th>
                                <th>Grade</th>
                                <th>Remark</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $index = 1; foreach ($termData['scores'] as $item): ?>
                            <tr>
                                <td><?php echo $index++; ?></td>
                                <td><?php echo htmlspecialchars($item['subject_name'] ?: 'Unknown Subject'); ?></td>
                                <td><?php echo number_format((float)$item['score'], 2); ?>%</td>
                                <td><?php echo htmlspecialchars($item['grade_name']); ?></td>
                                <td><?php echo htmlspecialchars($item['grade_remark']); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="alert alert-secondary">
                    <strong>Term Average:</strong> <?php echo number_format($termAverage, 2); ?>% &nbsp;|&nbsp;
                    <strong>Term Grade:</strong> <?php echo htmlspecialchars($termGrade['name']); ?> &nbsp;|&nbsp;
                    <strong>Remark:</strong> <?php echo htmlspecialchars($termGrade['remark']); ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php elseif ($student_id !== ''): ?>
<div class="row mt-3">
    <div class="col-md-12"><div class="tile"><p class="mb-0">No transcript records found for the selected student.</p></div></div>
</div>
<?php endif; ?>
</main>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>
<script src="loader/waitMe.js"></script>
<script src="js/forms.js"></script>
<script src="js/sweetalert2@11.js"></script>
<?php if (file_exists('const/check-reply.php')) { require_once('const/check-reply.php'); } ?>
</body>
</html>
