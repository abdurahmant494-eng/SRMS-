<?php
chdir('../');
session_start();
require_once('db/config.php');
require_once('const/school.php');
require_once('const/check_session.php');

if ($res != '1' || $level != '4') {
    header('location:../');
    exit;
}

$summary = ['total_results' => 0, 'avg_score' => 0, 'highest_score' => 0, 'lowest_score' => 0];
$status_summary = ['draft' => 0, 'submitted' => 0, 'verified' => 0, 'published' => 0];
$detail_rows = [];

try {
    $conn = new PDO('mysql:host='.DBHost.';dbname='.DBName.';charset='.DBCharset.';collation='.DBCollation.';prefix='.DBPrefix.'', DBUser, DBPass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $summary = $conn->query("SELECT COUNT(*) AS total_results, AVG(score) AS avg_score, MAX(score) AS highest_score, MIN(score) AS lowest_score FROM tbl_exam_results")->fetch(PDO::FETCH_ASSOC);
    $detail_rows = $conn->query("SELECT term, class, COUNT(*) AS total_results, AVG(score) AS avg_score FROM tbl_exam_results GROUP BY term, class ORDER BY term DESC, class ASC LIMIT 12")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $summary = ['total_results' => 0, 'avg_score' => 0, 'highest_score' => 0, 'lowest_score' => 0];
    $detail_rows = [];
}

$role_title = 'Exam Officer';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Borana University - Result Processing</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<base href="../">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link rel="icon" href="images/icon.ico">
<link rel="stylesheet" type="text/css" href="cdn.jsdelivr.net/npm/bootstrap-icons%401.10.5/font/bootstrap-icons.css">
<link type="text/css" rel="stylesheet" href="loader/waitMe.css">
</head>
<body class="app sidebar-mini">
<header class="app-header"><a class="app-header__logo" href="javascript:void(0);">
<img src="images/logo/<?php echo WBLogo; ?>" alt="<?php echo WBName; ?> logo">
<span><?php echo WBName; ?></span>
</a>
<a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
<ul class="app-nav"><li class="dropdown"><a class="app-nav__item" href="#" data-bs-toggle="dropdown" aria-label="Open Profile Menu"><i class="bi bi-person fs-4"></i></a>
<ul class="dropdown-menu settings-menu dropdown-menu-right">
<li><a class="dropdown-item" href="exam_officer/profile"><i class="bi bi-person me-2 fs-5"></i> My Profile</a></li>
<li><a class="dropdown-item" href="exam_officer/settings"><i class="bi bi-gear me-2 fs-5"></i> Settings</a></li>
<li><a class="dropdown-item" href="logout"><i class="bi bi-box-arrow-right me-2 fs-5"></i> Logout</a></li>
</ul></li></ul>
</header>
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
<div class="app-sidebar__user">
<div>
<p class="app-sidebar__user-name"><?php echo $fname.' '.$lname; ?></p>
<p class="app-sidebar__user-designation"><?php echo $role_title; ?></p>
</div>
</div>
<ul class="app-menu">
<li><a class="app-menu__item" href="exam_officer"><i class="app-menu__icon feather icon-monitor"></i><span class="app-menu__label">Dashboard</span></a></li>
<li><a class="app-menu__item" href="exam_officer/exam_scheduler"><i class="app-menu__icon feather icon-calendar"></i><span class="app-menu__label">Exam Scheduler</span></a></li>
<li><a class="app-menu__item" href="exam_officer/grade_submission"><i class="app-menu__icon feather icon-upload"></i><span class="app-menu__label">Grade Submission</span></a></li>
<li><a class="app-menu__item active" href="exam_officer/result_processing"><i class="app-menu__icon feather icon-bar-chart-2"></i><span class="app-menu__label">Result Processing</span></a></li>
<li><a class="app-menu__item" href="exam_officer/invigilation"><i class="app-menu__icon feather icon-users"></i><span class="app-menu__label">Invigilation Duty</span></a></li>
<li class="treeview"><a class="app-menu__item" href="javascript:void(0);" data-toggle="treeview"><i class="app-menu__icon feather icon-file-text"></i><span class="app-menu__label">Reports</span><i class="treeview-indicator bi bi-chevron-right"></i></a>
<ul class="treeview-menu">
<li><a class="treeview-item" href="exam_officer/reports/result_slips">Result Slips</a></li>
<li><a class="treeview-item" href="exam_officer/reports/transcripts">Transcripts</a></li>
<li><a class="treeview-item" href="exam_officer/reports/attendance">Exam Attendance</a></li>
</ul></li>
<li><a class="app-menu__item" href="exam_officer/analytics"><i class="app-menu__icon feather icon-pie-chart"></i><span class="app-menu__label">Analytics</span></a></li>
</ul>
</aside>
<main class="app-content">
<div class="app-title">
<div>
<p class="dashboard-eyebrow">Borana University Exam Operations</p>
<h1>Result Processing</h1>
<p>Review current exam result summaries and preparation status for publication.</p>
</div>
</div>
<div class="row">
<div class="col-md-3"><div class="tile"><h5>Total Results</h5><p class="fs-3 mb-0"><?php echo number_format((int)$summary['total_results']); ?></p></div></div>
<div class="col-md-3"><div class="tile"><h5>Average Score</h5><p class="fs-3 mb-0"><?php echo number_format((float)$summary['avg_score'], 2); ?></p></div></div>
<div class="col-md-3"><div class="tile"><h5>Best Score</h5><p class="fs-3 mb-0"><?php echo number_format((float)$summary['highest_score'], 2); ?></p></div></div>
<div class="col-md-3"><div class="tile"><h5>Lowest Score</h5><p class="fs-3 mb-0"><?php echo number_format((float)$summary['lowest_score'], 2); ?></p></div></div>
</div>
<div class="row mt-4">
<div class="col-md-12">
<div class="tile">
<h3 class="tile-title"><i class="bi bi-clipboard-data me-2"></i>Processing Status</h3>
<div class="row">
<div class="col-md-3"><div class="alert alert-secondary mb-0"><strong>Draft</strong><br><?php echo (int)$status_summary['draft']; ?></div></div>
<div class="col-md-3"><div class="alert alert-info mb-0"><strong>Submitted</strong><br><?php echo (int)$status_summary['submitted']; ?></div></div>
<div class="col-md-3"><div class="alert alert-warning mb-0"><strong>Verified</strong><br><?php echo (int)$status_summary['verified']; ?></div></div>
<div class="col-md-3"><div class="alert alert-success mb-0"><strong>Published</strong><br><?php echo (int)$status_summary['published']; ?></div></div>
</div>
</div>
</div>
</div>
<div class="row mt-4">
<div class="col-md-12"><div class="tile"><h3 class="tile-title"><i class="bi bi-table me-2"></i>Result Breakdown</h3><div class="table-responsive"><table class="table table-hover"><thead><tr><th>Term</th><th>Class</th><th>Total Records</th><th>Average Score</th></tr></thead><tbody><?php if (count($detail_rows) > 0): foreach ($detail_rows as $row): ?><tr><td><?php echo (int)$row['term']; ?></td><td><?php echo (int)$row['class']; ?></td><td><?php echo (int)$row['total_results']; ?></td><td><?php echo number_format((float)$row['avg_score'], 2); ?></td></tr><?php endforeach; else: ?><tr><td colspan="4" class="text-center">No result data available yet.</td></tr><?php endif; ?></tbody></table></div></div></div></div>
</main>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>
<script src="loader/waitMe.js"></script>
<script src="js/forms.js"></script>
<script src="js/sweetalert2@11.js"></script>
</body>
</html>
