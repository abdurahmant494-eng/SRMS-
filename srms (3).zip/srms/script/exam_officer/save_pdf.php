<?php
chdir('../');
session_start();
require_once('db/config.php');
require_once('const/school.php');
require_once('const/check_session.php');
require_once('tcpdf/tcpdf.php');
require_once('const/calculations.php');

if ($res != '1' || $level != '4' || WBResAvi != '1') {
    header('Location: ../');
    exit;
}

$std = isset($_GET['std']) ? trim($_GET['std']) : '';
$term = isset($_GET['term']) ? (int)$_GET['term'] : 0;

if ($std === '' || $term <= 0) {
    header('Location: ../exam_officer/reports/result_slips');
    exit;
}

try {
    $conn = new PDO('mysql:host='.DBHost.';dbname='.DBName.';charset='.DBCharset.';collation='.DBCollation.';prefix='.DBPrefix.'', DBUser, DBPass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $gradeStmt = $conn->prepare('SELECT * FROM tbl_grade_system');
    $gradeStmt->execute();
    $grade_system = $gradeStmt->fetchAll(PDO::FETCH_ASSOC);

    $sql = "SELECT s.student_id, s.fname, s.mname, s.lname, c.name AS class_name, t.name AS term_name, er.subject_name, er.score, er.grade, g.name AS grade_name, g.remark AS grade_remark
            FROM tbl_exam_results er
            JOIN tbl_students s ON s.student_id = er.student_id
            JOIN tbl_classes c ON c.id = s.class_id
            JOIN tbl_terms t ON t.id = er.term_id
            LEFT JOIN tbl_grade_system g ON er.grade = g.name
            WHERE er.student_id = :std AND er.term_id = :term AND er.published = 1
            ORDER BY er.subject_name ASC";

    $stmt = $conn->prepare($sql);
    $stmt->execute([':std' => $std, ':term' => $term]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo '<p class="alert alert-danger">Connection failed: ' . htmlspecialchars($e->getMessage()) . '</p>';
    exit;
}

if (!$results) {
    echo '<p class="alert alert-warning">No published results found for this student and term.</p>';
    exit;
}

$student = $results[0];
$fullName = trim($student['fname'] . ' ' . $student['mname'] . ' ' . $student['lname']);

function localGradeForScore($score, $grade_system)
{
    foreach ($grade_system as $grade) {
        if ($score >= (float)$grade['min'] && $score <= (float)$grade['max']) {
            return [
                'name' => $grade['name'],
                'remark' => $grade['remark'],
            ];
        }
    }
    return ['name' => 'N/A', 'remark' => 'N/A'];
}

$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('SRMS Exam Officer');
$pdf->SetTitle('Result Slip - ' . $fullName);
$pdf->SetSubject('Exam Result Slip');
$pdf->SetMargins(15, 20, 15);
$pdf->SetHeaderMargin(10);
$pdf->SetFooterMargin(10);
$pdf->SetAutoPageBreak(TRUE, 15);
$pdf->AddPage();

$html = '<h2 style="text-align:center;">Result Slip</h2>';
$html .= '<table cellspacing="0" cellpadding="4" border="0" style="width:100%; font-size:12px;">
            <tr><td><strong>Name:</strong> ' . htmlspecialchars($fullName) . '</td><td><strong>Student ID:</strong> ' . htmlspecialchars($student['student_id']) . '</td></tr>
            <tr><td><strong>Class:</strong> ' . htmlspecialchars($student['class_name']) . '</td><td><strong>Term:</strong> ' . htmlspecialchars($student['term_name']) . '</td></tr>
        </table>';

$html .= '<table cellspacing="0" cellpadding="4" border="1" style="width:100%; font-size:11px; border-collapse:collapse;">
            <thead>
                <tr style="background-color:#f2f2f2;">
                    <th width="10%">#</th>
                    <th width="45%">Subject</th>
                    <th width="15%">Score</th>
                    <th width="15%">Grade</th>
                    <th width="15%">Remark</th>
                </tr>
            </thead>
            <tbody>';

$totalScore = 0;
$count = 0;
foreach ($results as $row) {
    $count++;
    $score = (float)$row['score'];
    $totalScore += $score;
    $gradeItem = $row['grade_name'] ? ['name' => $row['grade_name'], 'remark' => $row['grade_remark'] ?: ''] : localGradeForScore($score, $grade_system);
    $remark = $gradeItem['remark'];
    $html .= '<tr>';
    $html .= '<td style="text-align:center;">' . $count . '</td>';
    $html .= '<td>' . htmlspecialchars($row['subject_name'] ?: 'Unknown Subject') . '</td>';
    $html .= '<td style="text-align:center;">' . number_format($score, 2) . '%</td>';
    $html .= '<td style="text-align:center;">' . htmlspecialchars($gradeItem['name']) . '</td>';
    $html .= '<td>' . htmlspecialchars($gradeItem['remark']) . '</td>';
    $html .= '</tr>';
}

$average = $count ? round($totalScore / $count, 2) : 0;
$averageGrade = localGradeForScore($average, $grade_system);
$html .= '</tbody></table>';
$html .= '<table cellspacing="0" cellpadding="4" border="0" style="width:100%; font-size:12px; margin-top:10px;">
            <tr><td><strong>Total Subjects:</strong> ' . $count . '</td><td><strong>Average Score:</strong> ' . number_format($average, 2) . '%</td></tr>
            <tr><td><strong>Grade:</strong> ' . htmlspecialchars($averageGrade['name']) . '</td><td><strong>Remark:</strong> ' . htmlspecialchars($averageGrade['remark']) . '</td></tr>
        </table>';

$pdf->writeHTML($html, true, false, true, false, '');
$pdf->Output('result-slip-' . preg_replace('/[^A-Za-z0-9]/', '-', $student['student_id']) . '-' . (int)$term . '.pdf', 'I');
