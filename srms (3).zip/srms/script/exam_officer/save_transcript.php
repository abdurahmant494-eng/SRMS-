<?php
chdir('../');
session_start();
require_once('db/config.php');
require_once('const/school.php');
require_once('const/check_session.php');
require_once('tcpdf/tcpdf.php');
require_once('const/calculations.php');

if ($res != '1' || $level != '4' || WBResAvi != '1') {
    header('Location: ../');
    exit;
}

$std = isset($_GET['std']) ? (int)$_GET['std'] : 0;
$term = isset($_GET['term']) ? (int)$_GET['term'] : 0;
$classFilter = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;

if ($std <= 0) {
    header('Location: ../exam_officer/reports/transcripts');
    exit;
}

try {
    $conn = new PDO('mysql:host='.DBHost.';dbname='.DBName.';charset='.DBCharset.';collation='.DBCollation.';prefix='.DBPrefix.'', DBUser, DBPass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $gradeStmt = $conn->prepare('SELECT * FROM tbl_grade_system ORDER BY min DESC');
    $gradeStmt->execute();
    $grade_system = $gradeStmt->fetchAll(PDO::FETCH_ASSOC);

    $profileStmt = $conn->prepare('SELECT s.id AS student_id, s.student_id AS student_number, s.fname, s.mname, s.lname, c.name AS class_name
        FROM tbl_students s
        JOIN tbl_classes c ON s.class = c.id
        WHERE s.id = ?');
    $profileStmt->execute([$std]);
    $student = $profileStmt->fetch(PDO::FETCH_ASSOC);

    if (!$student) {
        echo '<p class="alert alert-warning">Student not found.</p>';
        exit;
    }

    $conditions = 'er.student = :std AND er.published = 1';
    $params = [':std' => $std];

    if ($classFilter > 0) {
        $conditions .= ' AND er.class = :class_id';
        $params[':class_id'] = $classFilter;
    }
    if ($term > 0) {
        $conditions .= ' AND er.term = :term';
        $params[':term'] = $term;
    }

    $sql = "SELECT er.*, t.id AS term_id, t.name AS term_name, c.name AS class_name, sub.name AS subject_name,
            COALESCE(er.grade, g.name) AS grade_name, COALESCE(g.remark, 'N/A') AS grade_remark
        FROM tbl_exam_results er
        JOIN tbl_terms t ON er.term = t.id
        JOIN tbl_classes c ON er.class = c.id
        LEFT JOIN tbl_subject_combinations sc ON er.subject_combination = sc.id
        LEFT JOIN tbl_subjects sub ON sc.subject = sub.id
        LEFT JOIN tbl_grade_system g ON er.score BETWEEN g.min AND g.max
        WHERE $conditions
        ORDER BY t.id ASC, sub.name ASC";

    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo '<p class="alert alert-danger">Connection failed: ' . htmlspecialchars($e->getMessage()) . '</p>';
    exit;
}

if (!$results) {
    echo '<p class="alert alert-warning">No published transcript results found for this student.</p>';
    exit;
}

function localGradeForScore($score, $grade_system)
{
    foreach ($grade_system as $grade) {
        if ($score >= (float)$grade['min'] && $score <= (float)$grade['max']) {
            return [
                'name' => $grade['name'],
                'remark' => $grade['remark'],
            ];
        }
    }
    return ['name' => 'N/A', 'remark' => 'N/A'];
}

$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('SRMS Exam Officer');
$pdf->SetTitle('Transcript - ' . trim($student['fname'] . ' ' . $student['mname'] . ' ' . $student['lname']));
$pdf->SetSubject('Student Transcript');
$pdf->SetMargins(15, 20, 15);
$pdf->SetHeaderMargin(10);
$pdf->SetFooterMargin(10);
$pdf->SetAutoPageBreak(TRUE, 15);
$pdf->AddPage();

$fullName = trim($student['fname'] . ' ' . $student['mname'] . ' ' . $student['lname']);
$html = '<h2 style="text-align:center;">Student Transcript</h2>';
$html .= '<table cellspacing="0" cellpadding="4" border="0" style="width:100%; font-size:12px;">
            <tr><td><strong>Name:</strong> ' . htmlspecialchars($fullName) . '</td><td><strong>Student No:</strong> ' . htmlspecialchars($student['student_number']) . '</td></tr>
            <tr><td><strong>Class:</strong> ' . htmlspecialchars($student['class_name']) . '</td><td><strong>Generated:</strong> ' . date('Y-m-d') . '</td></tr>
        </table>';

if ($term > 0) {
    $html .= '<h3 style="margin-top:16px;">Term: ' . htmlspecialchars($results[0]['term_name']) . '</h3>';
}

$termSections = [];
foreach ($results as $row) {
    $termId = (int)$row['term_id'];
    if (!isset($termSections[$termId])) {
        $termSections[$termId] = [
            'term_name' => $row['term_name'],
            'class_name' => $row['class_name'],
            'scores' => [],
            'total_score' => 0,
            'subject_count' => 0,
        ];
    }
    $score = (float)$row['score'];
    $termSections[$termId]['scores'][] = $row;
    $termSections[$termId]['total_score'] += $score;
    $termSections[$termId]['subject_count']++;
}

$pageIndex = 0;
foreach ($termSections as $termId => $section) {
    if ($pageIndex > 0) {
        $pdf->AddPage();
    }
    $pageIndex++;
    $html .= '<h4 style="margin-top:16px;">Term: ' . htmlspecialchars($section['term_name']) . '</h4>';
    $html .= '<table cellspacing="0" cellpadding="4" border="1" style="width:100%; font-size:11px; border-collapse:collapse;">
                <thead>
                    <tr style="background-color:#f2f2f2;">
                        <th width="8%">#</th>
                        <th width="48%">Subject</th>
                        <th width="14%">Score</th>
                        <th width="15%">Grade</th>
                        <th width="15%">Remark</th>
                    </tr>
                </thead>
                <tbody>';

    $index = 1;
    foreach ($section['scores'] as $item) {
        $gradeItem = trim($item['grade_name']) !== '' ? ['name' => $item['grade_name'], 'remark' => $item['grade_remark']] : localGradeForScore((float)$item['score'], $grade_system);
        $html .= '<tr>';
        $html .= '<td style="text-align:center;">' . $index++ . '</td>';
        $html .= '<td>' . htmlspecialchars($item['subject_name'] ?: 'Unknown Subject') . '</td>';
        $html .= '<td style="text-align:center;">' . number_format((float)$item['score'], 2) . '%</td>';
        $html .= '<td style="text-align:center;">' . htmlspecialchars($gradeItem['name']) . '</td>';
        $html .= '<td>' . htmlspecialchars($gradeItem['remark']) . '</td>';
        $html .= '</tr>';
    }

    $average = $section['subject_count'] ? round($section['total_score'] / $section['subject_count'], 2) : 0;
    $sectionGrade = localGradeForScore($average, $grade_system);
    $html .= '</tbody></table>';
    $html .= '<table cellspacing="0" cellpadding="4" border="0" style="width:100%; font-size:12px; margin-top:10px;">
                <tr><td><strong>Subject Count:</strong> ' . $section['subject_count'] . '</td><td><strong>Average:</strong> ' . number_format($average, 2) . '%</td></tr>
                <tr><td><strong>Grade:</strong> ' . htmlspecialchars($sectionGrade['name']) . '</td><td><strong>Remark:</strong> ' . htmlspecialchars($sectionGrade['remark']) . '</td></tr>
            </table>';
}

$pdf->writeHTML($html, true, false, true, false, '');

$fileName = 'transcript-' . preg_replace('/[^A-Za-z0-9]/', '-', $student['student_number']) . ($term > 0 ? '-term-' . $term : '') . '.pdf';
$pdf->Output($fileName, 'I');
