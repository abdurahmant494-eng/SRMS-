<?php
chdir('../');
session_start();
require_once('db/config.php');
require_once('const/school.php');
require_once('const/check_session.php');

if ($res != '1' || $level != '4') {
    header('location:../');
    exit;
}

$role_title = 'Exam Officer';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Borana University - Settings</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<base href="../">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link rel="icon" href="images/icon.ico">
<link rel="stylesheet" type="text/css" href="cdn.jsdelivr.net/npm/bootstrap-icons%401.10.5/font/bootstrap-icons.css">
<link type="text/css" rel="stylesheet" href="loader/waitMe.css">
</head>
<body class="app sidebar-mini">
<header class="app-header"><a class="app-header__logo" href="javascript:void(0);">
<img src="images/logo/<?php echo WBLogo; ?>" alt="<?php echo WBName; ?> logo">
<span><?php echo WBName; ?></span>
</a>
<a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
<ul class="app-nav">
<li class="dropdown"><a class="app-nav__item" href="#" data-bs-toggle="dropdown" aria-label="Open Profile Menu"><i class="bi bi-person fs-4"></i></a>
<ul class="dropdown-menu settings-menu dropdown-menu-right">
<li><a class="dropdown-item" href="exam_officer/profile"><i class="bi bi-person me-2 fs-5"></i> My Profile</a></li>
<li><a class="dropdown-item" href="exam_officer/settings"><i class="bi bi-gear me-2 fs-5"></i> Settings</a></li>
<li><a class="dropdown-item" href="logout"><i class="bi bi-box-arrow-right me-2 fs-5"></i> Logout</a></li>
</ul></li>
</ul>
</header>
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
<div class="app-sidebar__user">
<div>
<p class="app-sidebar__user-name"><?php echo $fname.' '.$lname; ?></p>
<p class="app-sidebar__user-designation"><?php echo $role_title; ?></p>
</div>
</div>
<ul class="app-menu">
<li><a class="app-menu__item" href="exam_officer"><i class="app-menu__icon feather icon-monitor"></i><span class="app-menu__label">Dashboard</span></a></li>
<li><a class="app-menu__item" href="exam_officer/exam_scheduler"><i class="app-menu__icon feather icon-calendar"></i><span class="app-menu__label">Exam Scheduler</span></a></li>
<li><a class="app-menu__item" href="exam_officer/grade_submission"><i class="app-menu__icon feather icon-upload"></i><span class="app-menu__label">Grade Submission</span></a></li>
<li><a class="app-menu__item" href="exam_officer/result_processing"><i class="app-menu__icon feather icon-bar-chart-2"></i><span class="app-menu__label">Result Processing</span></a></li>
<li><a class="app-menu__item" href="exam_officer/invigilation"><i class="app-menu__icon feather icon-users"></i><span class="app-menu__label">Invigilation Duty</span></a></li>
<li class="treeview"><a class="app-menu__item" href="javascript:void(0);" data-toggle="treeview"><i class="app-menu__icon feather icon-file-text"></i><span class="app-menu__label">Reports</span><i class="treeview-indicator bi bi-chevron-right"></i></a>
<ul class="treeview-menu">
<li><a class="treeview-item" href="exam_officer/reports/result_slips">Result Slips</a></li>
<li><a class="treeview-item" href="exam_officer/reports/transcripts">Transcripts</a></li>
<li><a class="treeview-item" href="exam_officer/reports/attendance">Exam Attendance</a></li>
</ul></li>
<li><a class="app-menu__item" href="exam_officer/analytics"><i class="app-menu__icon feather icon-pie-chart"></i><span class="app-menu__label">Analytics</span></a></li>
</ul>
</aside>
<main class="app-content">
<div class="app-title">
<div>
<h1>Settings</h1>
<p>Secure your exam officer account and manage access settings.</p>
</div>
</div>
<div class="row">
<div class="col-md-8">
<div class="tile">
<h3 class="tile-title">Change Password</h3>
<div class="tile-body">
<form class="app_frm" action="exam_officer/core/update_password" method="POST" autocomplete="off">
<div class="mb-2">
<label class="form-label">Current Password</label>
<input type="password" class="form-control" name="cpassword" placeholder="Enter your current password">
</div>
<div class="mb-2">
<label class="form-label">New Password</label>
<input type="password" class="form-control" name="npassword" placeholder="Enter your new password">
</div>
<button type="submit" name="submit" value="1" class="btn btn-primary">Change Password</button>
</form>
</div>
</div>
</div>
</div>
</main>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>
<script src="loader/waitMe.js"></script>
<script src="js/forms.js"></script>
<script src="js/sweetalert2@11.js"></script>
<?php require_once('const/check-reply.php'); ?>
</body>
</html>
