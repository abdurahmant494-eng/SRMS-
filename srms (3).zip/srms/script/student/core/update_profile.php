<?php
chdir('../../');
session_start();
require_once('db/config.php');
require_once('const/check_session.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old_photo = isset($_POST['old_photo']) ? $_POST['old_photo'] : 'DEFAULT';
    $img = $old_photo;
    $upload_dir = 'images/students/';

    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }

    if (!isset($_FILES['profile_photo']) || $_FILES['profile_photo']['error'] === UPLOAD_ERR_NO_FILE) {
        $_SESSION['reply'] = array (array('warning', 'Please choose a profile photo to upload'));
        header('location:../view');
        exit;
    }

    if ($_FILES['profile_photo']['error'] === UPLOAD_ERR_OK) {
        $photo = $_FILES['profile_photo'];
        $extension = strtolower(pathinfo($photo['name'], PATHINFO_EXTENSION));
        $allowed = ['png', 'jpg', 'jpeg'];

        if (!in_array($extension, $allowed)) {
            $_SESSION['reply'] = array (array('warning','Invalid profile photo format. Please upload PNG or JPG.'));
            header('location:../view');
            exit;
        }

        $new_filename = uniqid('student_', true).'.'.$extension;
        $destination = $upload_dir.$new_filename;

        if (move_uploaded_file($photo['tmp_name'], $destination)) {
            if ($old_photo !== 'DEFAULT' && file_exists($upload_dir.$old_photo)) {
                unlink($upload_dir.$old_photo);
            }
            $img = $new_filename;
        } else {
            $_SESSION['reply'] = array (array('warning','Unable to upload profile photo.'));
            header('location:../view');
            exit;
        }
    }

    try {
        $conn = new PDO('mysql:host='.DBHost.';dbname='.DBName.';charset='.DBCharset.';collation='.DBCollation.';prefix='.DBPrefix.'', DBUser, DBPass);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $conn->prepare("UPDATE tbl_students SET display_image = ? WHERE id = ?");
        $stmt->execute([$img, $account_id]);

        $_SESSION['reply'] = array (array('success','Profile photo updated successfully'));
        header('location:../view');
        exit;

    } catch(PDOException $e) {
        echo "Connection failed: " . $e->getMessage();
    }
} else {
    header('location:../');
}
